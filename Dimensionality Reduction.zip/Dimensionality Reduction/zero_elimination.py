import numpy as np


def eli_zero(data, ax):
    for i, v in enumerate(data):
        if v[ax-1] == 0 and v[ax-2] == 0:
            v[ax] = 0
    return(data)