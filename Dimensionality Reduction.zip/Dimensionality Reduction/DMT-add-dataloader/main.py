from typing import Any
import numpy as np
import torch
from torch._C import device
import torch.optim as optim
from multiprocessing import Pool
import dataloader
import Loss.dmt_loss as dmt_loss
import Loss.dmt_loss_fast as dmt_loss_fast
import Loss.dmt_loss_fast_2 as dmt_loss_fast_2
import model.dmt_model as dmt_model
from torch import nn, set_flush_denormal
import paramENC as paramzzl
from tqdm import trange

import tool
import resource
soft, hard = resource.getrlimit(resource.RLIMIT_AS)
resource.setrlimit(resource.RLIMIT_AS, (int(0.5 * 1024 ** 6), hard))

torch.set_num_threads(1)

def train(
        args: dict,
        Model: Any,
        data: Any,
        target: Any,
        optimizer: Any,
        epoch: int,
        Loss: Any):

    BATCH_SIZE = args['batch_size']

    Model.train()

    num_train_sample = data.shape[0]
    num_batch = (num_train_sample - 0.5) // BATCH_SIZE + 1
    rand_index_i = torch.randperm(num_train_sample, device=Model.device).long()
    # rand_index_i = torch.range(start=0, end=num_train_sample, device=Model.device).long()
    train_loss_sum = [0, 0, 0, 0, 0, 0, 0]

    for batch_idx in torch.arange(0, num_batch):
        start = (batch_idx * BATCH_SIZE).int().to(Model.device)
        end = torch.min(
            torch.tensor(
                [batch_idx * BATCH_SIZE + BATCH_SIZE,
                 num_train_sample])).to(Model.device)
        sample_index_i = rand_index_i[start:end.int()]

        optimizer.zero_grad()
        input_data = data[sample_index_i].to(Model.device)
        output = Model(input_data, sample_index_i)
        loss_list = Loss(output, sample_index_i,
                         Model.Generate(output.detach())[0], data=input_data,)

        loss_list[0].backward()
        # loss_list[1].backward()
        train_loss_sum[0] += loss_list[0].item()
        # train_loss_sum[1] += loss_list[1].item()

        # if (args['trainquiet'] == 0) and (epoch % 10 == 0):
        #     print('batch {} loss {}'.format(batch_idx, loss_list[0].item()))

        optimizer.step()

    if args['trainquiet'] == 0 and (epoch % 100 == 0):
        print('Train Epoch: {} [{}/{} ({:.0f}%)] \t Loss: {}'.format(
            epoch, batch_idx * BATCH_SIZE, num_train_sample,
            BATCH_SIZE * 100. * batch_idx / num_train_sample, train_loss_sum))
        print('current nu:', Loss.vList[-1])

    return train_loss_sum


def Test(
        args: dict,
        Model: Any,
        data: Any,
        target: Any,
        optimizer: Any,
        epoch: int):

    Model.eval()
    BATCH_SIZE = args['batch_size']
    num_train_sample = data.shape[0]
    num_batch = (num_train_sample - 0.5) // BATCH_SIZE + 1
    rand_index_i = torch.arange(num_train_sample)

    for batch_idx in torch.arange(0, num_batch):
        start = (batch_idx * BATCH_SIZE).int()
        end = torch.min(
            torch.tensor(
                [batch_idx * BATCH_SIZE + BATCH_SIZE, num_train_sample]))
        sample_index_i = rand_index_i[start:end.int()]

        datab = data.float()[sample_index_i]
        em = Model.test(datab)
        re = Model.Generate(em[-1])
        # print(em[0])

        em = em[-1].detach().cpu().numpy()
        re = re[-1].detach().cpu().numpy()
        if batch_idx == 0:
            outem = em
            outre = re
        else:
            outem = np.concatenate((outem, em), axis=0)
            outre = np.concatenate((outre, re), axis=0)

    return outem, outre


def main(args: dict, data_train=None, label_train=None, data_test=None, label_test=None):

    tool.SetSeed(args['seed'])
    path = tool.GetPath(args['data_name'])
    tool.SaveParam(path, args)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    if data_train is None:
        data_train, label_train = dataloader.GetData(args, device=device)
        data_test, label_test = dataloader.GetData(args, device=device, testBool=True)
    else:
        data_train = torch.tensor(data_train)#.to(device)
        label_train = torch.tensor(label_train)#.to(device)
        data_test = torch.tensor(data_test)#.to(device)
        label_test = torch.tensor(label_test)#.to(device)

    
    Loss = dmt_loss_fast.LISV2_Loss(data_train, device=device, args=args, path=path).to(device)
    # Loss = dmt_loss_fast_2.LISV2_Loss(data_train, device=device, args=args, path=path).to(device)
    Model = dmt_model.LISV2_MLP(data_train, device=device, args=args, path=path, loss=Loss).to(device)

    optimizer = optim.Adam(Model.parameters(), lr=args['lr'])

    gifPloterLatentTrain = tool.GIFPloter()
    gifPloterLatentTest = tool.GIFPloter()
    gifPloterrecons = tool.GIFPloter()
    
    loss_his = []
    for epoch in trange(0, args['epochs'] + 1):
        Loss.epoch = epoch

        loss_item = train(args, Model, data_train, label_train, optimizer, epoch, Loss)
        loss_his.append(loss_item)

        if epoch == 500:
            for param_group in optimizer.param_groups:
                param_group["lr"] = param_group["lr"] / 10
            print('change the learning rate')

        if epoch % args['log_interval'] == 0:

            em_train, re_train = Test(args, Model, data_train, label_train, optimizer, epoch)
            gifPloterLatentTrain.AddNewFig(
                em_train,
                label_train.detach().cpu(),
                his_loss=loss_his,
                path=path,
                graph=Model.GetInput(),
                link=None,
                title_='train_epoch_em{}_{}{}.png'.format(
                    epoch, args['perplexity'], args['v'])
                )

            em_test, re_test = Test(args, Model, data_test, label_test, optimizer, epoch)
            gifPloterLatentTest.AddNewFig(
                em_test,
                label_test.detach().cpu(),
                his_loss=loss_his,
                path=path,
                graph=Model.GetInput(),
                link=None,
                title_='test_epoch_em{}_{}{}.png'.format(
                    epoch, args['perplexity'], args['v']))

            if args['Dec']:
                if epoch == 0:
                    input_data = data_train.detach().cpu().numpy()
                else:
                    input_data = re_train
                gifPloterrecons.AddNewFig(
                    input_data,
                    label_train.detach().cpu(),
                    his_loss=loss_his,
                    path=path,
                    graph=Model.GetInput(),
                    link=None,
                    title_='train_epoch_re{}_{}{}.png'.format(
                        epoch, args['perplexity'], args['v']),
                    dataset=args['name'])
            
            tool.SaveData(
                data_train,
                em_train,
                label_train,
                # dist=Model.dist,
                path=path,
                name='train_epoch{}'.format(str(epoch).zfill(6)))

    gifPloterLatentTrain.SaveGIF()

    return path


if __name__ == "__main__":

    args = paramzzl.GetParamswishroll()
    # args = paramzzl.GetParamScurve()
    # args = paramzzl.GetParamseveredsphere()
    # args = paramzzl.GetParamSphere5500()
    # args = paramzzl.GetParamSphere10000()
    # args = paramzzl.GetParamcoil20()
    # args = paramzzl.GetParamcoil100rgb()
    # args = paramzzl.GetParamMnistL()
    # args = paramzzl.GetParamFMnistL()
    # args = paramzzl.GetParamDuplicate()
    # args = paramzzl.GetParamCifa10()
    # args = paramzzl.GetParamPbmc3k()
    path = main(args)

    # import indicator
    # indicator.main()
