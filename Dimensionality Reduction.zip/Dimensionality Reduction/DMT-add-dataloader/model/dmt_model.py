# a pytorch based lisv2 code
# author: zelinzang
# email: zangzelin@gmail.com

import functools
import pdb
import time
from locale import currency
from multiprocessing import Pool
from typing import Any

import numpy as np
import torch
import torch.autograd
from torch import nn, set_flush_denormal
# from pso import generate
# import Queue



class LISV2_MLP(torch.nn.Module):
    def __init__(
        self,
        data: torch.tensor,
        device: Any,
        args: dict,
        path: str,
        loss: Any,
        n_dim=2,
    ):

        super(LISV2_MLP, self).__init__()
        with torch.no_grad():
            self.device = device
            self.phis = []
            self.n_points = data.shape[0]
            self.n_dim = n_dim
            self.args = args
            self.args['NetworkStructure'][0] = data.shape[1]
            self.NetworkStructure = args['NetworkStructure']
            self.dataset_name = args['data_name']
            self.loss = loss
            # self.data = data.float().to(self.device)

            self.InitNetwork()

    def InitNetwork(self):
        self.encoder = nn.ModuleList()
        for i in range(len(self.NetworkStructure) - 1):
            self.encoder.append(
                nn.Linear(self.NetworkStructure[i],
                          self.NetworkStructure[i + 1]))
            if i != len(self.NetworkStructure) - 2:
                self.encoder.append(nn.LeakyReLU(0.1))

        self.decoder = nn.ModuleList()
        for i in range(len(self.NetworkStructure) - 1, 0, -1):
            self.decoder.append(
                nn.Linear(self.NetworkStructure[i],
                          self.NetworkStructure[i - 1]))
            if i != 1:
                self.decoder.append(nn.LeakyReLU(0.1))
        # Map output to range (0, 1) for image datasets
        if('mnist' in self.dataset_name or 'coil' in self.dataset_name):
            self.decoder.append(nn.Sigmoid())

    def GetInput(self):
        return None

    def forward(self, data, input_data_index):

        self.loss.ChangeVList()
        x = data

        for i, layer in enumerate(self.encoder):
            x = layer(x)

        return x

    def Generate(self, latent):

        x = latent
        for i, layer in enumerate(self.decoder):
            x = layer(x)

        return [x]

    def test(self, input_data):

        self.loss.ChangeVList()
        x = input_data.to(self.device)

        for i, layer in enumerate(self.encoder):
            x = layer(x)

        return [x]

