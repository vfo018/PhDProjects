
import paramENC
import numpy as np
from typing import Any
import main
import dataloader

def main_open_sourse(
    data_name=None,
    data_train=None,
    label_train=None,
    data_test=None,
    label_test=None,
    method='LISv2_m',
    perplexity=10,
    v_s=0.001,
    v_e=100,
    NetworkStructure=[-1, 500, 500, 2], 
    batch_size=800,
    epochs=5000,
    lr=1e-3,
    seed=1,
    log_interval=1000,
    trainquiet=0
):
    args = paramENC.GetParamswishroll()
    args['data_name'] = data_name
    args['method'] = method
    args['perplexity'] = perplexity
    args['v'] = v_s
    args['vtrace'] = [v_s, v_e]
    args['NetworkStructure'] = NetworkStructure
    args['batch_size'] = batch_size
    args['epochs'] = epochs
    args['lr'] = lr
    args['seed'] = seed
    args['log_interval'] = log_interval
    args['trainquiet'] = trainquiet
    main.main(args, data_train, label_train, data_test, label_test)

def loadTestdata():
    n = 100
    data0 = [0.0]*100
    data5 = [5.0]*100
    data10 = [10.0]*100
    
    data = []
    label = []
    for i in range(n):
        data.append(data0)
        data.append(data5)
        data.append(data10)
        label.append(0)
        label.append(1)
        label.append(2)
    data_train = np.array(data)
    label_train = np.array(label)

    return data_train, label_train

if __name__ == "__main__":
    # main_open_sourse(data_name='swishroll')
    
    data_train, label_train = loadTestdata()
    main_open_sourse(
        data_name='Test',
        data_train=data_train,
        label_train=label_train,
        data_test=data_train,
        label_test=label_train,
        )