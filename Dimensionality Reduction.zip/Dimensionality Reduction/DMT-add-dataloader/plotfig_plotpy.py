import numpy as np
# import visdom
import os
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy
# import indicator

# vis = visdom.Visdom(port=5501)


def FindContainList(strList, conList):
    out = []
    for strs in strList:
        if conList in strs:
            out.append(strs)

    out.sort()
    return out


def ReadDict(path):
    import pandas as pd
    import json
    path = path+'/param.txt'
    f = open(path, 'r')
    strs = f.read()

    keys = list(json.loads(strs).keys())
    vals = list(json.loads(strs).values())

    return keys, vals


def PlotWithPlotlyIndex(path=None, Maxnumber=1, index=-1, outpath=None):

    listname = os.listdir(path)
    print(listname)
    listContaininput = FindContainList(listname, 'input.txt')
    listContainlabel = FindContainList(listname, 'label.txt')
    listContainlatent = FindContainList(listname, 'latent.txt')

    inputdatapath = path+'/'+listContaininput[-1]
    labeldatapath = path+'/'+listContainlabel[-1]
    latentdatapath = path+'/'+listContainlatent[index]

    data_input = np.loadtxt(inputdatapath)
    data_latent = np.loadtxt(latentdatapath)
    data_label = np.loadtxt(labeldatapath)

    data_latent = data_latent-data_latent.mean(axis=0)

    data = go.Scatter(
        mode='markers',
        name=latentdatapath,
        x=data_latent[:, 0],
        y=data_latent[:, 1],
        marker=dict(
            color=data_label.astype(np.int32),
            size=3,
            opacity=1
        )
    )

    keys, vals = ReadDict(path)
    x_shift = (data_latent[:, 0].max()-data_latent[:, 0].min())/5
    x_s, x_e = data_latent[:, 0].max()+x_shift, data_latent[:, 0].max()+x_shift
    y_s, y_e = data_latent[:, 1].min(), data_latent[:, 1].max()
    x_list = np.linspace(x_s, x_e, len(keys))
    y_list = np.linspace(y_s, y_e, len(keys))

    str_print = []
    for i in range(len(keys)):
        str_print.append(str(keys[i]) + '\t:' + str(vals[i]))

    str_print.sort(key=lambda x: len(x))

    data2 = go.Scatter(
        mode='text',
        x=x_list,
        y=y_list,
        text=str_print,
        textposition='middle left'
    )

    layout = go.Layout(
        paper_bgcolor='rgba(255,255,255,1)',
        plot_bgcolor='rgba(255,255,255,1)',
        # title_text=str_print
    )

    fig = go.Figure(data=[data, data2], layout=layout, )
    fig.update_xaxes(showline=True, linewidth=1, linecolor='black')
    fig.update_yaxes(showline=True, linewidth=1, linecolor='black')
    fig.update_layout(showlegend=False)
    fig.update_layout(height=800, width=800, title_text="detail scatters")

    if outpath is not None:
        # print(latentdatapath[:-4])
        path = outpath+'/'+latentdatapath[:-4].split('/')[-2]
    else:
        path = latentdatapath[:-4]

    fig.write_image(path+'LastOneaVis.png')


def PlotWithPlotly(path=None, manNumberFig=15):

    print(path)
    listname = os.listdir(path)
    listContaininput = FindContainList(listname, 'input.txt')
    listContainlabel = FindContainList(listname, 'label.txt')
    listContainlatent = FindContainList(listname, 'latent.txt')

    numAllFig = len(listContainlatent)
    if numAllFig > manNumberFig:
        figIndexList = [int(i*numAllFig//manNumberFig)
                        for i in range(manNumberFig)]
    else:
        figIndexList = [int(i) for i in range(numAllFig)]
    numUseFig = len(figIndexList)+1

    titleList = [listContainlatent[i] for i in figIndexList]
    titleList.append('table')

    numRow = int(np.sqrt(numUseFig-0.01))+1  # hang
    numcols = int((numUseFig-0.001)//numRow)+1  # lei

    specs = []
    num = 0
    for i in range(numRow):
        specsi = []
        for j in range(numcols):
            num += 1
            if num < numUseFig:
                specsi.append({"type": "scatter"})
            else:
                specsi.append({"type": "table"})
                # break
        specs.append(specsi)

    fig = make_subplots(
        rows=numRow,
        cols=numcols,
        subplot_titles=titleList,
        specs=specs,
    )

    print('fig number {}'.format(numUseFig))
    for i in range(numUseFig):
        # print(i)
        print(1+i//numcols, 1+i % numcols, '/', numRow, numcols)
        if i < numUseFig-1:
            inputdatapath = path+'/'+listContaininput[-1]
            labeldatapath = path+'/'+listContainlabel[-1]
            latentdatapath = path+'/'+listContainlatent[i]

            data_input = np.loadtxt(inputdatapath)
            data_latent = np.loadtxt(latentdatapath)
            data_label = np.loadtxt(labeldatapath)

            data_latent = data_latent-data_latent.mean(axis=0)

            fig.append_trace(
                go.Scatter(
                    mode='markers',
                    name=titleList[i],
                    x=data_latent[:, 0],
                    y=data_latent[:, 1],
                    marker=dict(
                        color=data_label.astype(np.int32),
                        size=3,
                        opacity=1
                    )
                ), 1+i//numcols, 1+i % numcols,
            )
        else:
            keys, vals = ReadDict(path)
            fig.append_trace(
                go.Table(
                    header=dict(values=['key', 'value'],
                                fill_color='paleturquoise',
                                align='left'),
                    cells=dict(values=[keys, vals],
                               fill_color='lavender',
                               align='left'),
                ), 1+i//numcols, 1+i % numcols,
            )
    fig.update_layout(showlegend=False,
                      paper_bgcolor='rgba(255,255,255,1)',
                      plot_bgcolor='rgba(255,255,255,1)',)
    fig.update_layout(height=2000, width=2000, title_text="detail scatters")

    fig.write_image(path+'/'+titleList[-1][:-3]+'stepavis.png')

if __name__ == "__main__":
    path = 'log'
    dirlist = os.listdir(path)
    dirlist.sort()
    for dirItem in dirlist:
        p = path+'/'+dirItem
        print(p)
        if ('2020' in p):
            try:
                PlotWithPlotlyIndex(path=p, index=-1, outpath='log/baseline')
            except:
                print('error', p)
    # PlotWithPlotly(path='log/20200719102650_42017LISv2_m')
