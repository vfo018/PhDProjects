# a pytorch based lisv2 code
# author: zelinzang
# email: zangzelin@gmail.com

import functools
import pdb
import time
from locale import currency
from multiprocessing import Pool
from typing import Any
import os
import numpy as np
import torch
import torch.autograd
import torch.nn.functional as F
from pynndescent import NNDescent
from torch import nn, set_flush_denormal
import pickle

class LISV2_Loss(nn.Module):
    def __init__(
        self,
        data: torch.tensor,
        device: Any,
        args: dict,
        path: str,
        n_dim=2,
    ):

        super(LISV2_Loss, self).__init__()
        self.ReconstructionLoss = nn.MSELoss()

        with torch.no_grad():
            self.mseLossFunc = nn.MSELoss()
            self.device = device
            self.phis = []
            self.n_points = data.shape[0]
            self.n_dim = n_dim
            self.perplexity = args['perplexity']
            self.args = args
            self.args['NetworkStructure'][0] = data.shape[1]
            self.NetworkStructure = args['NetworkStructure']
            self.epoch = 0
            self.dataset_name = args['data_name']
            self.vList = [100] + [1] * (len(args['NetworkStructure']) - 1)
            self.gammaList = self.CalGammaF(self.vList)

            print('start to claculate sigma')
            dist = self.Distance_squared(data, data, savepath=path).float()

            path='{}_{}_{}'.format(args['data_name'],dist.mean(),self.n_points)
            
            if os.path.exists('save/'+path+'.pickle'):
                print('------->load', path)
                rho_input, self.sigmaListlayer = pickle.load(open('save/'+path+'.pickle', 'rb'))
            else:
                print('------->save', path)
                rho_input, self.sigmaListlayer = self.InitSigmaSearchEverySample(
                    self.gammaList, self.vList, data)
                pickle.dump(
                    [rho_input, self.sigmaListlayer], 
                    open('save/'+path+'.pickle', 'wb')
                    )
                print('------->save', path)
            
            self.P = torch.tensor(self.CalPtnumpy(
                dist.numpy(),
                rho_input.numpy(),
                self.sigmaListlayer[0].cpu().numpy(),
                gamma=self.gammaList[0],
                v=self.vList[0],
                split=1)).float().detach().to(self.device)

            
            s = np.log10(self.args['vtrace'][0])
            e = np.log10(self.args['vtrace'][1])
            self.vListForEpoch = np.concatenate([
                np.zeros((1000, )) + 10**s,
                np.logspace(s, e, 2000),
                np.zeros((17001, )) + 10**e,
            ])
            print('init LISV2_MLP mocol model, gaama is: {}'.format(
                self.gammaList))
            self.data = data.float().to(self.device)
            torch.cuda.empty_cache()

    def InitSigmaSearchEverySample(
        self,
        gammaList,
        vList,
        data,
        # dist,
    ):
        # dist = np.power(pairwise_distances(data, data, n_jobs=-1), 2, )
        # distC = np.copy(dist)
        # distC[distC < (1e-11)] = 1e16
        # rho = np.min(distC, axis=1)
        print('finish find rho')
        index = NNDescent(data, n_jobs=-1)
        print('step 1 NNDescent')
        neighbors_index, neighbors_dist = index.query(data, k= min(1440, data.shape[0]) )
        neighbors_dist = np.power(neighbors_dist, 2)
        print(neighbors_dist)
        print('step 2 query')
        rho = neighbors_dist[:, 1]

        print('start pool search')
        sigmaListlayer = [0] * len(self.args['NetworkStructure'])

        r = PoolRunner(self.n_points,
                       self.perplexity,
                       neighbors_dist,
                       rho,
                       gammaList[0],
                       vList[0],
                       pow=self.args['pow'])
        sigmaListlayer[0] = torch.tensor(r.Getout()).to(self.device)

        std_dis = np.std(rho) / np.sqrt(data.shape[1])
        print('std', std_dis)

        if std_dis > 0.2:
            for i in range(1, len(self.args['NetworkStructure'])):
                sigmaListlayer[i] = torch.zeros(data.shape[0],
                                                device=self.device) + 1
        else:
            for i in range(0, len(self.args['NetworkStructure'])):
                sigmaListlayer[i] = torch.zeros(
                    data.shape[0],
                    device=self.device) + sigmaListlayer[0].mean() * 5
        return torch.tensor(rho), sigmaListlayer

    def CalGammaF(self, vList):
        import scipy
        out = []
        for v in vList:
            a = scipy.special.gamma((v + 1) / 2)
            b = np.sqrt(v * np.pi) * scipy.special.gamma(v / 2)
            out.append(a / b)

        return out

    def GetInput(self):
        return None

    def CalPt(self, dist, rho, sigma_array, gamma, v=100, split=1):

        if torch.is_tensor(rho):
            dist_rho = (dist - rho.reshape(-1, 1)) / sigma_array.reshape(-1, 1)
        else:
            dist_rho = dist
        dist_rho[dist_rho < 0] = 0

        Pij = torch.pow(
            gamma * torch.pow((1 + dist_rho / v), -1 * (v + 1) / 2) * \
            torch.sqrt(torch.tensor(2 * 3.14)), self.args['pow'])
        P = Pij + Pij.t() - torch.mul(Pij, Pij.t())

        return P

    def CalPtnumpy(self, dist, rho, sigma_array, gamma, v=100, split=1):

        if torch.is_tensor(rho):
            dist_rho = (dist - rho.reshape(-1, 1)) / sigma_array.reshape(-1, 1)
        else:
            dist_rho = dist
        dist_rho[dist_rho < 0] = 0

        Pij = np.power(
            gamma * np.power((1 + dist_rho / v), -1 * (v + 1) / 2) * \
            np.sqrt(np.array(2 * 3.14)), self.args['pow'])
        P = Pij + Pij.T - np.multiply(Pij, Pij.T)

        return P

    def Distance_squared(
        self,
        x,
        y,
        savepath=None,
    ):
        m, n = x.size(0), y.size(0)
        xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
        yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
        dist = xx + yy
        dist.addmm_(1, -2, x, y.t())
        d = dist.clamp(min=1e-12)
        d[torch.eye(d.shape[0]) == 1] = 1e-12

        return d

    def CE(self, P, Q):

        EPS = 1e-12
        # Q=(P+Q)/2
        # print([torch.eye(P.shape[0])==0])
        # input()
        P_ = P[torch.eye(P.shape[0])==0]*(1-2*EPS) + EPS
        Q_ = Q[torch.eye(P.shape[0])==0]*(1-2*EPS) + EPS
        losssum1 = (P_ * torch.log(Q_ + EPS)).mean()
        losssum2 = ((1-P_) * torch.log(1-Q_ + EPS)).mean()
        losssum = -1*(losssum1 + losssum2)

        if torch.isnan(losssum):
            input('stop and find nan')
        return losssum

    def forward(self, latent, input_data_index, generate, data=None):

        loss_ce = self.CE(P=self.P[input_data_index][:, input_data_index],
                          Q=self.CalPt(dist=self.Distance_squared(
                              latent, latent),
                                       rho=0,
                                       sigma_array=1,
                                       gamma=self.gammaList[-1],
                                       v=self.vList[-1]))
        loss_rc = self.ReconstructionLoss(
            # self.Generate(latentList[0].detach())[0],
            generate,
            self.data[input_data_index])
        return [loss_ce, loss_rc / 10]

    def ChangeVList(self):

        epoch = self.epoch
        self.vCurent = self.vListForEpoch[epoch]
        newVList = [100]
        for i in range(len(self.args['NetworkStructure']) - 1):
            newVList.append(self.vCurent)
        self.vList = newVList
        self.gammaList = self.CalGammaF(newVList)

    def Generate(self, latent):

        x = latent
        for i, layer in enumerate(self.decoder):
            x = layer(x)

        return [x]

    def test(self, input_data):

        self.ChangeVList()
        x = input_data.to(self.device)

        for i, layer in enumerate(self.encoder):
            x = layer(x)

        return [x]


class PoolRunner(object):
    def __init__(self, n, N_NEIGHBOR, dist, rho, gamma, v, pow=2):
        pool = Pool(processes=30)
        result = []
        
        # path = 'save/savesigma_{}_{}_{}_{}_{}_{}.npy'.format(n,N_NEIGHBOR,dist.mean(),rho.mean(),gamma.mean(),v)
        # if os.path.exists(path):
        #     print('load', path)
        #     self.sigma_array = np.load(path)
        # else:
        for dist_row in range(n):

            result.append(
                pool.apply_async(sigma_binary_search,
                                (N_NEIGHBOR, dist[dist_row], rho[dist_row],
                                gamma, v, pow)))
        print('start calculate sigma')
        pool.close()
        pool.join()
        sigma_array = []
        for i in result:
            sigma_array.append(i.get())
        self.sigma_array = np.array(sigma_array)
        print("\nMean sigma = " + str(np.mean(sigma_array)))
        print('finish calculate sigma')
        # np.save(path, self.sigma_array)
        # print('save', path)

    def Getout(self, ):
        return self.sigma_array

def sigma_binary_search(fixed_k, dist_row_line, rho_line, gamma, v, pow=2):
    """
    Solve equation k_of_sigma(sigma) = fixed_k
    with respect to sigma by the binary search algorithm
    """
    sigma_lower_limit = 0
    sigma_upper_limit = 1000
    for i in range(20):
        approx_sigma = (sigma_lower_limit + sigma_upper_limit) / 2
        k_value = func(approx_sigma,
                       dist_row_line,
                       rho_line,
                       gamma,
                       v,
                       pow=pow)
        if k_value < fixed_k:
            sigma_lower_limit = approx_sigma
        else:
            sigma_upper_limit = approx_sigma
        if np.abs(fixed_k - k_value) <= 1e-4:
            break
    return approx_sigma


def func(sigma, dist_row_line, rho_line, gamma, v, pow=2):
    d = (dist_row_line - rho_line) / sigma
    d[d < 0] = 0
    p = np.power(
        gamma * np.power((1 + d / v), -1 * (v + 1) / 2) * np.sqrt(2 * 3.14),
        pow)
    return np.power(2, np.sum(p))
