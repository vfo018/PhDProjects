import socket

#SOCK_DGRAM = UDP。

client = socket.socket(type=socket.SOCK_DGRAM)

send_data  =b'[[1.12724005],[1.43994028],[1.85707897],[2.17008523],[2.48322106],[2.79648606],[3.21437291],[3.49812788],[3.81183193],[4.12566278],[4.33495467],[4.64899685],[4.96316447],[5.14290872][5.45729672],[5.6669576],[5.87667438],[6.19135203],[6.26652243],[6.47641091]]'

client.sendto(send_data,('192.168.1.70',7890))

re_Data,address = client.recvfrom(1024)

print('server>>',re_Data.decode('utf-8'))

client.close()
