import numpy as np
import random


def cal_dif(data1, data2, threshold):
    # label = []
    data1_new = data1[:]
    for i, v in enumerate(data2):
        a = 0
        d = sum(np.power(v, 2))
        # print(d)
        for j, u in enumerate(v):
            a += np.power(u - data1[i][j], 2)
            # print(u)
            # print(data1[i][j])
            # print(a)
        if a > threshold * d:
            n = round(random.uniform(-0.1, 0.1), 4)
            # print(n)
            data1_new[i] = (1 + n) * data2[i]
        # elif v[0] == 0 and v[1] == 0:
        #     label.append(1)

        # print(a)
    return data1_new


# a = np.array([[-0.23228, -1.79036, 0.95964], [-0.02524, -0.74627, 1.02659], [-0.06632, 0.36381, 1.09037]])
# b = np.array([[-0.29827, -1.76543, 1.14261], [-0.09559, -0.71970, 1.22167], [0.09992, 0.30102, 0.62942]])
# l = cal_dif(a, b, 0.1)
