#server

import socket

#SOCK_DGRAM = UDP。

server = socket.socket(type=socket.SOCK_DGRAM)

server.bind(('192.168.1.70',7890))

#without listen, receive data from client directly

print('The server is open on port 7890 and is waiting to be connected...')

# recvFrom () method returns the data, address and port of the client.
# the server directly calls sendto() and sends the data to the client using UDP  

data,address = server.recvfrom(1024)

print("client>>",data.decode('utf-8'))

print("The socket address of the client connection：",  address)

server.sendto(b'Recevied',address)

server.close()
