import numpy as np
from scipy.spatial import distance


def create_label(data, threshold):
    label, data0 = [1], []
    # print(len(data[0]))
    if len(data[0]) > 3:
        data = data[:, 3:]
        # print('Here')
    elif len(data[0]) == 3:
        data = data[:, :]
        # print(data)
    data_transmitted = data[0]
    for i in range(1, len(data)):
        dis = distance.euclidean(data[i], data_transmitted)
        data_norm = np.linalg.norm(data[i])
        if dis > threshold * data_norm:
            data_transmitted = data[i]
            label.append(1)
        else:
            label.append(0)
    return np.array(label)
