import numpy as np
from scipy.spatial import distance


def distancepearsoncorrelation(X, Z):
    """
    Calculates the distance pearson correlation measure between the data space `X` and the
    latent space `Z`, given a neighbourhood parameter `k` for setting up
    the extent of neighbourhoods.

    This is just the 'flipped' variant of the 'trustworthiness' measure.
    """

    X_mean = np.mean(X)
    Z_mean = np.mean(Z)
    X_std = np.std(X)
    Z_std = np.std(Z)
    sum_cov = 0
    print(len(X))
    for i in range(0, len(X)):
        for j in range(0, len(X)):
            if i != j:
                sum_cov += ((distance.euclidean(X[i:], X[j:]) - X_mean) / X_std) * \
                           ((distance.euclidean(Z[i:], Z[j:]) - Z_mean) / Z_std)

    DPC = sum_cov / ((len(X) - 1))
    return DPC
