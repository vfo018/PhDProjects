import numpy as np
import pandas as pd
from PCAcopy import pca
from indicator import MeasureCalculator
from indicator import GetIndicatorData
from distancepearsoncorrelation import distancepearsoncorrelation
from create_label import create_label
from cal_transmission_bit import cal_transmission_bit
#“indicator”的目的是可视化由“值”属性指定的单个值。可以使用三个不同的视觉元素来表示该值：数字、增量和量规

datas = pd.read_csv('Dynamic_interaction_pushing_side_face_cube_25s_RecordedTOPSession_DB.csv')
datas1 = datas.iloc[1:3334, 1:4].values    #from column 4 to 10 and label has 9018 columns
label_1 = create_label(datas1,0.1)
##t-SNE data dimensional reduction processing
datas = pd.read_csv('Dynamic_interaction_pushing_side_face_cube_25s_RecordedTOPSession_DB.csv',
                    usecols=['SF_x', 'SF_y', 'SF_z', 'MV_x', 'MV_y', 'MV_z', 'MP_x', 'MP_y', 'MP_z'], nrows=10000)
                    ##select datas 20000 rows
#print(datas)
df = pd.DataFrame(datas)   ## create dataframe
df = df[~df['SF_x'].isin([0])]   ## select and clean non-zero data on SF series
datas2 =df.iloc[0:10000, 3:10]   ##select the actual training data
#print(datas2)



my_data = pd.read_table('Dynamic_interaction_pushing_side_face_cube_25s_RecordedTOPSession_DB.csv', sep=',')
data_set = my_data.iloc[0:3000, 4:10].values
training_set = my_data.iloc[0:2000, 4:10].values
test_set = my_data.iloc[2000:3000, 4:10].values
# x_simple = np.array([-2, -1, 0, 1, 2])
# y_simple = np.array([4, 1, 3, 2, 0])
# DPC = distancepearsoncorrelation(x_simple, y_simple)
test_set_pca, eig_vec, test_set_reconstruction = pca(test_set, 3)
# my_calculator = MeasureCalculator(test_set, test_set_pca, 20, None)

# label = cal_label(training_set)
# CON = my_calculator.continuity(50)
# TRU = my_calculator.trustworthiness(50)
# DPC = my_calculator.distancepearsoncorrelation()
label = create_label(test_set, 0.1)
# bit = cal_transmission_bit(test_set_pca, 'pca')
a = 0
for i, v in enumerate(label):
    if v == 1:
        a += 1
indicator = GetIndicatorData(real_data=test_set, latent=test_set_pca, label=label, kmax=50, Name='LD-sliding-2000:3000-pv-pca', save_path='pca_test.txt')
#原始数据realdata，
# Force
data_set_f = my_data.iloc[0:3000, 1:4].values
training_set_f = my_data.iloc[0:2000, 1:4].values
test_set_f = my_data.iloc[2000:3000, 1:4].values
# x_simple = np.array([-2, -1, 0, 1, 2])
# y_simple = np.array([4, 1, 3, 2, 0])
# DPC = distancepearsoncorrelation(x_simple, y_simple)
test_set_pca_f, eig_vec_f, test_set_reconstruction_f = pca(test_set_f, 2)

label_f = create_label(test_set_f, 0.1)
indicator_f = GetIndicatorData(real_data=test_set_f, latent=test_set_pca_f, label=label_f, kmax=50, Name='LD-sliding-2000:3000-f-pca', save_path='pca_test.txt')
