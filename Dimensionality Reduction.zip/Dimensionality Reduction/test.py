import numpy as np
from indicator import Distance_squared


# a = np.array([[1, -np.power(1/2, 1/2), 0],
#               [-np.power(1/2, 1/2), 1, -np.power(1/2, 1/2)],
#               [0, -np.power(1/2, 1/2), 1]])
a = np.array([[1, -1, 0],
              [-1, 2, -1],
              [0, -1, 1]])
s, v = np.linalg.eig(a)

# a = [0, 2, 3], [2, 3, 4], [1, 3, 4]
# d = Distance_squared(a, a)
# e = np.sum(d, axis=-1)
# f = e / e.sum(axis=-1)
# a = np.array([[1, 2], [3, 4]])  # 初始化一个非奇异矩阵(数组)
# print(np.linalg.inv(a))
#
# A = np.matrix(a)
# print(A.I)
# a = np.array([[-4.56200104, -21.2336912]])
# U = np.array([[-0.30253213, -0.87499307],
#                 [-0.86718533,  0.08811216],
#                 [0.39555518, -0.47604975]])
#
# X = np.array([[10, 15, 29]])
# Z = np.dot(X, U)
# print(Z)
# U_inv = np.matrix(U).I
# U_T_inv = np.matrix(U.T).I
# X_appr = np.dot(Z, U_inv)
# X_appr0 = np.dot(U, Z.T)
# print(np.dot(U_inv, U))
# print(X_appr)
# print(X_appr0)
# print(np.dot(U.T, U_T_inv))
# print(np.dot(U_inv, Z))


# A = np.array([[1, 2, 6],
#                 [3,  7, 8],
#                 [5, 10, 9]])
# A_inv = np.matrix(A).I
# print(np.dot(A_inv, A))
# print(np.dot(A, A_inv))

# import sklearn.datasets
# import pandas as pd
# import numpy as np
# import umap
# import umap.plot
#
#
# pendigits = sklearn.datasets.load_digits()
# mnist = sklearn.datasets.fetch_openml('mnist_784')
# fmnist = sklearn.datasets.fetch_openml('Fashion-MNIST')
# mapper = umap.UMAP().fit(pendigits.data)
# umap.plot.points(mapper)

### Now cuml

# mapper = cuml.UMAP().fit(pendigits.data)

# umap.plot.points(mapper, labels = pendigits.target)

# from mpl_toolkits.mplot3d.axes3d import Axes3D
# fig = plt.figure()
# axes3d = Axes3D(fig)
# axes3d.scatter3D(x, y, np.log(x+y))
# plt.show()