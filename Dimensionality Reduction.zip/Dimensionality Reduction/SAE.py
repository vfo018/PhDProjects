"""##Importing the libraries"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.optim as optim
import torch.utils.data
from torch.autograd import Variable
from indicator import GetIndicatorData
from create_label import create_label

"""## Importing the dataset"""
# movies = pd.read_csv('ml-1m/movies.dat', sep='::', header=None, engine='python', encoding='latin-1')
# users = pd.read_csv('ml-1m/users.dat', sep='::', header=None, engine='python', encoding='latin-1')
# ratings = pd.read_csv('ml-1m/ratings.dat', sep='::', header=None, engine='python', encoding='latin-1')

## Preparing the training set and the test set
my_data = pd.read_table('texture - RU - sliding - output.txt', sep='  ')
training_set = my_data.iloc[0:2000, 4:10].values
training_set0 = my_data.iloc[0:2000, 4:10].values
test_set = my_data.iloc[2000:3000, 4:10].values
test_set0 = my_data.iloc[2000:3000, 4:10].values

nb_dimensions = training_set.shape[1]
nb_data = training_set.shape[0]

## Converting the data into Torch tensors
training_set = torch.FloatTensor(training_set)
test_set = torch.FloatTensor(test_set)


## Creating the architecture of the Neural Network
# Inheritance from Module
class SAE(nn.Module):
    def __init__(self, ):
        super(SAE, self).__init__()
        # Parameters: Number of features, number of neurons,
        self.fc1 = nn.Linear(nb_dimensions, 4)
        self.fc2 = nn.Linear(4, 3)
        # Start Decoding
        self.fc3 = nn.Linear(3, 4)
        self.fc4 = nn.Linear(4, nb_dimensions)
        self.activation = nn.Sigmoid()
        # self.activation = torch.relu()

    def forward(self, x):
        # # Encoding
        # x = self.fc1(x)
        # x = torch.relu(x)
        # x = self.fc2(x)
        # x = torch.relu(x)
        # x_encoded = x
        # # Decoding
        # x = self.fc3(x)
        # x = torch.relu(x)
        # x = self.fc4(x)
        # # x = torch.relu(x)
        x = self.activation(self.fc1(x))
        x = self.activation(self.fc2(x))
        x_encoded = x
        x = self.activation(self.fc3(x))
        x = self.fc4(x)
        return x, x_encoded


sae = SAE()
criterion = nn.MSELoss()
# lr: learning rates
optimizer = optim.Adam(sae.parameters(), lr=1e-3)

## Training the SAE
nb_epoch = 1000
for epoch in range(1, nb_epoch + 1):
    train_loss = 0.
    # s = 0.
    for id_data in range(nb_data):
        # Pytorch does not accept a single vector of one dimension as input
        input = Variable(training_set[id_data]).unsqueeze(0)
        target = input.clone()
        optimizer.zero_grad()
        output,  embedding = sae.forward(input)
        loss = criterion(output, target)
        # Compute the mean of errors
        # mean_corrector = nb_dimensions/float(torch.sum(target.data != 0) + 1e-10)
        loss.backward()
        # a = np.sqrt(loss.item()*mean_corrector)
        train_loss += loss.item()
        # s += 1.
        optimizer.step()
    print('epoch: ' + str(epoch) + ' loss: ' + str(train_loss/nb_data))

## Testing the SAE
nb_testdata = test_set.shape[0]
test_loss = 0
test_embedding, test_output = [], []
for id_data in range(nb_testdata):
    # Pytorch does not accept a single vector of one dimension as input
    test_input = Variable(test_set[id_data]).unsqueeze(0)
    test_target = test_input.clone()
    # optimizer.zero_grad()
    test_output_id, test_embedding_id = sae.forward(test_input)
    test_loss = criterion(test_output_id, test_target)
    # Compute the mean of errors
    # mean_corrector = nb_dimensions/float(torch.sum(target.data != 0) + 1e-10)
    # loss.backward()
    # a = np.sqrt(loss.item()*mean_corrector)
    test_loss += test_loss.item()
    # s += 1.
    # optimizer.step()
    test_output_id0 = test_output_id.cpu().detach().numpy().tolist()
    # print(test_output_id0)
    test_embedding_id0 = test_embedding_id.cpu().detach().numpy().tolist()
    test_embedding.append(test_embedding_id0)
    test_output.append(test_output_id0)

print('loss: ' + str(test_loss / nb_data))

test_output = np.array(test_output).reshape(1000, 6)
test_embedding = np.array(test_embedding).reshape(1000, 3)
# label = create_label(test_set, 0.1)
# indicator = GetIndicatorData(real_data=test_set, latent=test_embedding, label=label, kmax=50,
#                              Name='LD-sliding-2000:3000-pv-sae', save_path='test.txt')
np.save('RU_embedding_sae_pv.npy', test_embedding)
np.save('RU_reconstruction_sae_pv.npy', test_output)
# torch.save(sae.state_dict(), 'LD-SAE')
# sae = torch.load('RD-SAE')
