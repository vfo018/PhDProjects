from create_label import create_label



def cal_transmission_bit(data, threshold, type):
    total_bit = 0
    if type == 'pca':
        dim_new = len(data[0])
        print(dim_new)
        data_amount = len(data)
        print(data_amount)
        if dim_new == 3:
            total_bit = 8 * data_amount * dim_new + 8 * dim_new * 6
        elif dim_new == 2:
            total_bit = 8 * data_amount * dim_new + 8 * dim_new * 3

    elif type == 'codecs':
        label = create_label(data, threshold)
        data_amount = 0
        for i, v in enumerate(label):
            if v == 1:
                data_amount += 1
        dim = len(data[0])
        total_bit = 8 * data_amount * dim

    elif type == 'sae' or type == 'umap':
        dim_new = len(data[0])
        data_amount = len(data)
        total_bit = 8 * data_amount * dim_new

    return total_bit
