import socket
from numpy import linalg as la
import numpy as np
A = np.mat([[	0	,	0	,	0	]	,	[	0	,	0	,	0	]	,	[	-0.408954	,	-0.260439	,	1.892962	]   ,
[	0	,	0	,	0	]	,	[	0	,	0	,	0	]	,	[	-0.408954	,	-0.260439	,	1.892962	]	,
[	0	,	0	,	0	]	,	[	0	,	0	,	0	]])
# U, sigma, VT = la.svd(A)
# B=A.T * U[:,0:2]

signal=A
SNR =100
#random noise N(0,1)
noise = np.random.randn(signal.shape[0],signal.shape[1])
#average=0
noise = noise-np.mean(noise)
signal_power = np.linalg.norm( signal - signal.mean() )**2 / signal.size
noise_variance = signal_power/np.power(10,(SNR/10))
noise = (np.sqrt(noise_variance) / np.std(noise) )*noise    
signal_noise = noise + signal
Ps = ( np.linalg.norm(signal - signal.mean()) )**2          #signal power
Pn = ( np.linalg.norm(signal - signal_noise ) )**2          #noise power
snr = 10*np.log10(Ps/Pn)

client = socket.socket(type=socket.SOCK_DGRAM)
# send_data  = b'signal_noise'
send_data  = signal_noise

client.sendto(send_data,('192.168.1.70',7890))

re_Data,address = client.recvfrom(1024)

print('server>>',re_Data.decode('utf-8'))

client.close()

