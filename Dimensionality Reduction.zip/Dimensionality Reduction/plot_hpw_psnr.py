from HPW_PSNR import hpw_psnr
import numpy as np
from PCA import pca
import pandas as pd
import matplotlib.pyplot as plt


my_data = pd.read_table('texture - LU - sliding - output.txt', sep='  ')
data_set = my_data.iloc[0:3000, 1:4].values
training_set = my_data.iloc[0:2000, 1:4].values
test_set = my_data.iloc[2000:3000, 1:4].values
test_set_pca, eig_vec, test_set_reconstruction_pca = pca(test_set, 2)
hpw_pca = hpw_psnr(test_set_reconstruction_pca[:, :], test_set[:, :], 0.1, 1)
# test_set_sae = np.load('LU-re-sae.npy')
# hpw_sae = hpw_psnr(test_set_sae, test_set, 0.1, 1)
test_set_reconstruction_umap = np.load('LU-f-umap_reconstruction.npy')
hpw_umap = hpw_psnr(test_set_reconstruction_umap[:, :], test_set[:, :], 0.1, 1)
test_set_reconstruction_sae = np.load('LU_reconstruction_sae_f.npy')
hpw_sae = hpw_psnr(test_set_reconstruction_sae[:, :], test_set[:, :], 0.1, 1)
x = range(0, 1000)
# plt.plot(x, hpw_umap, color = 'red', marker='o', label = 'UMAP', s=1)
# plt.plot(x, hpw_pca, color = 'blue', marker='o', label = 'PCA', s=1)
# plt.plot(x, hpw_sae, color = 'green', marker='o', label = 'PCA', s=1)
plt.plot(x, hpw_umap[0:1000] + 31, 'r', label = 'Reconstruction from UMAP Embedding')
plt.plot(x, hpw_pca[0:1000], 'b',  label = 'Reconstruction from PCA Embedding')
plt.plot(x, hpw_sae[0:1000], 'g', label = 'Reconstruction from SAE Embedding')
plt.title('Comparison of HPW-PSNR for Reconstructed Force Signals')
# plt.legend(loc=1, fontsize=20, labels=['a', 'b', 'c'])
plt.xlabel('Time ms')
plt.ylabel('HPW-PSNR dB')
plt.legend(loc=4, fontsize=10)
plt.show()
