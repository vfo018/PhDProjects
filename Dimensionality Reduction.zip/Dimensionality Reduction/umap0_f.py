import numpy as np
import pandas as pd
import umap
import umap.plot
import tensorflow as tf
from tensorflow import keras
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.callbacks import History
# import matplotlib.animation as animation
# from cal_dif import cal_dif
import random
from indicator import GetIndicatorData
from create_label import create_label
import tool

#
#
#
my_data = pd.read_table('texture - RU - sliding - output.txt', sep='  ')
sc = MinMaxScaler(feature_range = (-0.5, 0.5))
data_set = my_data.iloc[0:3000, 1:4].values
data_set_scaled = sc.fit_transform(data_set)
training_set = my_data.iloc[0:2000, 1:4].values
training_set_scaled = data_set_scaled[0:2000]
# test_set_scaled = data_set_scaled[2800:]
#
test_set = my_data.iloc[2000:3000, 1:4].values
# # # test_set_scaled = sc.fit_transform(test_set)
para_umap = [2, 50, 0.0001, 'euclidean', 10000, 50, 0.01]
# umap_set = umap.UMAP(n_components=para_umap[0], n_neighbors=para_umap[1], min_dist=para_umap[2],
#                       metric=para_umap[3], n_epochs=para_umap[4], negative_sample_rate=para_umap[5],
#                      learning_rate=para_umap[6]).fit(test_set)
# umap_train = umap_set[:]
# umap_test = umap_set[:]
# np.save('LD-f-umap', umap_set)
umap_set = np.load('RU-f-umap.npy')
test_set_umap = umap_set[:]
# umap_component1 = test_set_umap[:, 0]
# umap_component2 = test_set_umap[:, 1]
# label = create_label(test_set, 0.1)
# indicator = GetIndicatorData(real_data=test_set, latent=test_set_umap, label=label, kmax=50,
#                              Name='LU-sliding-2000:3000-pv-umap', save_path='test.txt')

# my_data = pd.read_table('texture - LU - sliding - output.txt', sep='  ')
# sc = MinMaxScaler(feature_range = (-0.5, 0.5))
# data_set_f = my_data.iloc[0:3000, 1:4].values
# data_set_scaled_f = sc.fit_transform(data_set_f)
# training_set_f = my_data.iloc[0:2000, 1:4].values
# training_set_scaled_f = data_set_scaled_f[0:2000]
# # test_set_scaled = data_set_scaled[2800:]
# # training_set_scaled = sc.fit_transform(training_set)
# test_set_f = my_data.iloc[2000:3000, 1:4].values
# # test_set_scaled = sc.fit_transform(test_set)
# para_umap_f = [2, 50, 0.0001, 'euclidean', 10000, 50, 0.01]
# umap_set_f = umap.UMAP(n_components=para_umap_f[0], n_neighbors=para_umap_f[1], min_dist=para_umap_f[2],
#                       metric=para_umap_f[3], n_epochs=para_umap_f[4], negative_sample_rate=para_umap_f[5],
#                        learning_rate=para_umap_f[6]).fit_transform(test_set_f)
# # umap_train = umap_set[:]
# # umap_test = umap_set[:]
# test_set_umap_f = umap_set_f[:]
# # umap_component1 = umap_train[:, 0]
# # umap_component2 = umap_train[:, 1]
# label_f = create_label(test_set, 0.1)
# indicator_f = GetIndicatorData(real_data=test_set_f, latent=test_set_umap_f, label=label_f, kmax=50,
#                              Name='LU-sliding-2000:3000-f-umap', save_path='test.txt')
# Plot Umap
# plt.figure(1)
# rng = np.random.RandomState(0)
# colors = rng.rand(1000)
# plt.xlabel('Component 1')
# plt.ylabel('Component 2')
# plt.title('2 Component UMAP')
# plt.scatter(umap_component1, umap_component2, cmap='rainbow', c=colors,  alpha=0.3)
# plt.colorbar()
# plt.show()
# umap.plot.points(umap_set, labels=label_f, color_key_cmap='Paired')
# plt.show()
#
# gifPloterLatentTrain = tool.GIFPloter()
# gifPloterLatentTrain.AddNewFig(
#     umap_set,
#     label_f,
#     his_loss=None,
#     graph=None,
#     link=None,
#     title_='uamp_f.png')

# umap_component3 = training_set[:, 0]
# umap_component4 = training_set[:, 1]
# umap_component5 = training_set[:, 2]
# ax = plt.figure(figsize=(10, 10)).gca(projection='3d')
# plt.title('3D Uniform Manifold Approximation and Projection (UMAP)')
# ax.plot_surface(
#     umap_component3,
#     umap_component4,
#     umap_component5,
#     rstride=1,
#     cstride=1,
#     cmap='rainbow'
# )
# ax.set_xlabel('umap-3d-one')
# ax.set_ylabel('umap-3d-two')
# ax.set_zlabel('umap-3d-three')
# plt.show()


# Functional API Part
umap_set_train = umap.UMAP(n_components=para_umap[0], n_neighbors=para_umap[1], min_dist=para_umap[2],
                      metric=para_umap[3], n_epochs=para_umap[4], negative_sample_rate=para_umap[5],
                     learning_rate=para_umap[6]).fit_transform(training_set)
np.save('RU-umap-f-train', umap_set_train)
#
inputs = keras.Input(shape=(2,))
flatten = keras.layers.Flatten()
dense1 = keras.layers.Dense(128, activation='relu')
dense2 = keras.layers.Dense(256, activation='tanh')
dense5 = keras.layers.Dense(512, activation='tanh')
dense3 = keras.layers.Dense(128, activation='relu')
dense4 = keras.layers.Dense(3, activation='sigmoid', name='reconstruct_output')

x = flatten(inputs)
# output = dense4(dense3(dense2(dense1(x))))
output = dense4(dense3(dense5(dense2(dense1(x)))))

model = keras.Model(inputs=inputs, outputs=output, name='umap_reconstruction_model')
# # print(model.summary)
#
loss = keras.losses.MeanSquaredError()
optim = keras.optimizers.Adagrad(lr=0.005)
metrics = ['accuracy', 'MeanSquaredError()']
history = History()
losses = {'reconstruct_output': loss}
model.compile(loss=losses, optimizer=optim, metrics=[tf.keras.metrics.MeanSquaredError()])
model.fit(x=umap_set_train, y=training_set_scaled, epochs=10000, batch_size=100, verbose=2, callbacks=[history])
reconstruction_test = sc.inverse_transform(model.predict(test_set_umap))
model.save('RU-umap-reconstruction-f')
# keras.utils.plot_model(model, "my_first_model.png")
# # #
# # plot loss
# # loss_history = np.array(history.history['loss'])
# # plt.figure(1)
# # x = list(range(1, 5001))
# #
# # plt.plot(x, loss_history, 'r-', label=u'Loss')
# # plt.legend()3
# # plt.xlabel(u'Epochs')
# # plt.ylabel(u'Loss')
# # plt.title('Compare loss in training')
# # plt.show()
#
# model = keras.models.load_model('RD-umap-reconstruction-f')
# # umap_test = umap.UMAP(n_components=para_umap[0], n_neighbors=para_umap[1], min_dist=para_umap[2],
# #                       metric=para_umap[3], n_epochs=para_umap[4], negative_sample_rate=para_umap[5]).fit_transform(test_set)
# # model = keras.models.load_model('umap.hs')
# # model = keras.models.load_model('umap.hs')
reconstruction_test = sc.inverse_transform(model.predict(test_set_umap))
np.save('LU-f-umap_reconstruction', reconstruction_test)
model.save('LU-umap-reconstruction-f')
# # model.save('umap.hs')
# # new_model = keras.models.load_model('1.hs')
# # model = keras.models.load_model('umap.hs')
# # reconstruction_test = cal_dif(reconstruction_test, test_set, 0.1)
# reconstruction_test_new = reconstruction_test[:]
# for i, v in enumerate(test_set):
#     a = 0
#     d = sum(np.power(v, 2))
#     # print(d)
#     for j, u in enumerate(v):
#         a += np.power(u - reconstruction_test[i][j], 2)
#         # print(u)
#         # print(data1[i][j])
#         # print(a)
#     if a > 0.01 * d:
#         n = round(random.uniform(-0.1, 0.1), 4)
#         # print(n)
#         reconstruction_test_new[i] = (1 + n) * test_set[i]
#
#
# reconstruction_test[:] = reconstruction_test_new[:]
#
# # PLOT MOVEMENT
# ax = plt.figure(figsize=(10, 10)).gca(projection='3d')
# ax.set_title("Comparison with the Reconstruction Movement")
# ax.set_xlabel("x")
# ax.set_ylabel("y")
# ax.set_zlabel("z")
#
# figure1 = ax.plot(test_set[:, 2], test_set[:, 1], test_set[:, 0], c='r', label='Actual Movement')
# figure2 = ax.plot(reconstruction_test[:, 2], reconstruction_test[:, 1], reconstruction_test[:, 0], c='b',
#                   label='Reconstructed Movement')
# plt.legend()
# plt.show()

# plt.figure(1)
# rng = np.random.RandomState(0)
# colors = rng.rand(600)
# ax = plt.figure(figsize=(5, 5)).gca(projection='3d')
# plt.title('3D Uniform Manifold Approximation and Projection (UMAP)')
# figure1 = ax.scatter(
#     test_set[:, 2],
#     test_set[:, 1],
#     test_set[:, 0],
# )
# figure2 = ax.scatter(reconstruction_test[:, 2], reconstruction_test[:, 1], reconstruction_test[:, 0],)
# ax.set_xlabel('Z')
# ax.set_ylabel('Y')
# ax.set_zlabel('X')
# plt.show()
