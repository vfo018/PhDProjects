import numpy as np
import pandas as pd
import umap
import tensorflow as tf
from tensorflow import keras
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


my_data = pd.read_table('texture - LU - sliding - output.txt', sep=' ')
training_set = my_data.iloc[0:2000, 7:].values
test_set = my_data.iloc[2000:3000, 7:].values
para_umap = [1, 100, 0.1, 'euclidean']
umap_train = umap.UMAP(n_components=para_umap[0], n_neighbors=para_umap[1], min_dist=para_umap[2],
                      metric=para_umap[3]).fit_transform(training_set)
umap_component1_train = umap_train[:, 0]
# umap_component2_train = umap_train[:, 1]
# plt.figure()
# plt.xlabel('Component 1')
# plt.ylabel('Component 2')
# plt.title('2 Component UMAP')
# plt.scatter(umap_component1, umap_component2)
# plt.show()

# umap_component3 = embedding[:, 0]
# umap_component4 = embedding[:, 1]
# umap_component5 = embedding[:, 2]
# ax = plt.figure(figsize=(10, 10)).gca(projection='3d')
# plt.title('3D Uniform Manifold Approximation and Projection (UMAP)')
# ax.scatter(
#     xs=umap_component3,
#     ys=umap_component4,
#     zs=umap_component5,
#     #c = x_kmeans
# )
# ax.set_xlabel('umap-3d-one')
# ax.set_ylabel('umap-3d-two')
# ax.set_zlabel('umap-3d-three')
# plt.show()




# Functional API Part

inputs = keras.Input(shape=(1,))
flatten = keras.layers.Flatten()
# dense1 = keras.layers.Dense(64, activation='sigmoid')
dense2 = keras.layers.Dense(64, activation='relu')
dense3 = keras.layers.Dense(128, activation='relu')
dense4 = keras.layers.Dense(1, activation='sigmoid', name='reconstruct_x_output')
dense5 = keras.layers.Dense(1, activation='sigmoid', name='reconstruct_y_output')
dense6 = keras.layers.Dense(1, activation='sigmoid', name='reconstruct_z_output')

x = flatten(inputs)
# output = dense4(dense3(dense2(dense1(x))))
x = dense3(dense2(x))
output_x = dense4(x)
output_y = dense5(x)
output_z = dense6(x)
model = keras.Model(inputs=inputs, outputs=[output_x, output_y, output_z], name='umap_reconstruction_model')
# print(model.summary)

loss1, loss2, loss3 = keras.losses.MeanSquaredError(), keras.losses.MeanSquaredError(), keras.losses.MeanSquaredError()
optim = keras.optimizers.RMSprop(lr=0.001)
# metrics = ['accuracy', 'MeanSquaredError()']
losses = {'reconstruct_x_output': loss1, 'reconstruct_y_output': loss2, 'reconstruct_z_output': loss3}
model.compile(loss=losses, optimizer=optim, metrics=[tf.keras.metrics.MeanSquaredError()])
y = {'reconstruct_x_output': training_set[:, 0], 'reconstruct_y_output': training_set[:, 1],
     'reconstruct_z_output': training_set[:, 2]}
model.fit(x=umap_train, y=y, epochs=1000, batch_size=100, verbose=2)

umap_test = umap.UMAP(n_components=para_umap[0], n_neighbors=para_umap[1], min_dist=para_umap[2],
                      metric=para_umap[3]).fit_transform(test_set)
reconstruction_test = np.array(model.predict(umap_train)).reshape(2000, 3)
