import numpy as np
import pandas as pd
from indicator import MeasureCalculator
from indicator import GetIndicatorData
from distancepearsoncorrelation import distancepearsoncorrelation
from create_label import create_label
from cal_transmission_bit import cal_transmission_bit
from sklearn import manifold
#“indicator”的目的是可视化由“值”属性指定的单个值。可以使用三个不同的视觉元素来表示该值：数字、增量和量规


my_data = pd.read_table('Dynamic_interaction_pushing_side_face_cube_25s_RecordedTOPSession_DB.csv', sep=',')
data_set = my_data.iloc[0:3000, 4:10].values
training_set = my_data.iloc[0:2000, 4:10].values
test_set = my_data.iloc[2000:3000, 4:10].values
# x_simple = np.array([-2, -1, 0, 1, 2])
# y_simple = np.array([4, 1, 3, 2, 0])
# DPC = distancepearsoncorrelation(x_simple, y_simple)
test_set_tsne1 = pd.read_table('t_sne_output_datas_2D.csv', sep=',')
test_set_tsne = test_set_tsne1.iloc[2000:3000,1:3].values
#test_set_tsne, eig_vec, test_set_reconstruction = manifold.TSNE(test_set, 3)
# my_calculator = MeasureCalculator(test_set, test_set_pca, 20, None)

# label = cal_label(training_set)
# CON = my_calculator.continuity(50)
# TRU = my_calculator.trustworthiness(50)
# DPC = my_calculator.distancepearsoncorrelation()
label = create_label(test_set, 0.1)
# bit = cal_transmission_bit(test_set_pca, 'pca')
a = 0
for i, v in enumerate(label):
    if v == 1:
        a += 1
indicator = GetIndicatorData(real_data=test_set, latent=test_set_tsne, label=label, kmax=50, Name='2000:3000-pv-tsne', save_path='tsne_test.txt')
#原始数据realdata，
# Force
data_set_f = my_data.iloc[0:3000, 1:4].values
training_set_f = my_data.iloc[0:2000, 1:4].values
test_set_f = my_data.iloc[2000:3000, 1:4].values
# x_simple = np.array([-2, -1, 0, 1, 2])
# y_simple = np.array([4, 1, 3, 2, 0])
# DPC = distancepearsoncorrelation(x_simple, y_simple)
#test_set_tsne_f, eig_vec_f, test_set_reconstruction_f = manifold.TSNE(test_set_f, 2)
test_set_tsne_f = test_set_tsne1.iloc[2000:3000,1:2].values
label_f = create_label(test_set_f, 0.1)
indicator_f = GetIndicatorData(real_data=test_set_f, latent=test_set_tsne_f, label=label_f, kmax=50, Name='2000:3000-f-tsne', save_path='tsne_test.txt')
