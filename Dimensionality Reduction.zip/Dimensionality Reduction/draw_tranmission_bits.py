from cal_transmission_bit import cal_transmission_bit
import matplotlib.pyplot as plt
import numpy as np

import pandas as pd
from PCA import pca
from indicator import MeasureCalculator
from indicator import GetIndicatorData
from distancepearsoncorrelation import distancepearsoncorrelation
from create_label import create_label
from cal_transmission_bit import cal_transmission_bit


my_data = pd.read_table('texture - LU - sliding - output.txt', sep='  ')
data_set = my_data.iloc[0:3000, 4:10].values
training_set = my_data.iloc[0:2000, 4:10].values
test_set = my_data.iloc[2000:3000, 4:10].values
# x_simple = np.array([-2, -1, 0, 1, 2])
# y_simple = np.array([4, 1, 3, 2, 0])
# DPC = distancepearsoncorrelation(x_simple, y_simple)
test_set_pca, eig_vec, test_set_reconstruction = pca(test_set, 3)
# my_calculator = MeasureCalculator(test_set, test_set_pca, 20, None)

# label = cal_label(training_set)
# CON = my_calculator.continuity(50)
# TRU = my_calculator.trustworthiness(50)
# DPC = my_calculator.distancepearsoncorrelation()
# label = create_label(test_set, 0.1)

test_data = np.zeros([1000, 3])
# total_bit_pca = cal_transmission_bit(test_data, 0.1, 'pca')
threshold = [0, 0.02, 0.05, 0.1, 0.15, 0.2, 0.3]
# total_bit_lstm = list(map(round, (48000 * np.array([1, 0.98, 0.824, 0.428, 0.34, 0.304, 0.074])).tolist()))
# total_bit_codecs = list(map(round, (48000 * np.array([1, 0.988, 0.876, 0.586, 0.498, 0.416, 0.148])).tolist()))
# # total_bit_codecs = [48000, 42576, 37144, 33312, 29104, 23280, 17088]
# total_bit_umap = [24000, 24000, 24000, 24000, 24000, 24000, 24000]
# total_bit_pca = [26144, 26144, 26144, 26144, 26144, 26144, 26144]

# for m in threshold:
#     bit = cal_transmission_bit(test_set, m, 'codecs')
#     total_bit_codecs.append(bit)
# total_bit_umap = cal_transmission_bit(test_data, 0.1, 'umap')
# total_bit_sae = cal_transmission_bit(test_data, 0.1, 'sae')
x = [0, 1, 2, 3, 4, 5, 6]
DeadbandParameter = [0, 0.02, 0.05, 0.1, 0.15, 0.2, 0.3]
# r_v_LSTM = [1, 0.98, 0.824, 0.428, 0.34, 0.304, 0.074]
# r_v0 = [1, 0.988, 0.876, 0.586, 0.498, 0.416, 0.148]
# r_f_LSTM = [1, 0.928, 0.712, 0.386, 0.268, 0.104, 0.037]
# r_f0 = [1, 0.794, 0.598, 0.404, 0.256, 0.204, 0.156]
# plt.figure(1)
# plt.plot(x, total_bit_umap, color = 'blue', marker='o', label = 'UMAP&SAE')
# plt.plot(x, total_bit_pca, color = 'green', marker='o', label = 'PCA')
# plt.plot(x, total_bit_codecs, color = 'red', marker='o', label = 'PD-Based Codecs')
# plt.plot(x, total_bit_lstm, color = 'orange', marker='o', label = 'LSTM-Based Model')
# plt.xticks(x, (0, 0.02, 0.05, 0.1, 0.15, 0.2, 0.3))
# # plt.axis([-0.02, 0.3, 0, 1])
# plt.title('Comparison of Transmission Bits for Position/Velocity Signal')
# plt.xlabel('Deadband Parameter')
# plt.ylabel('Transmission Bits')
# for a, b in zip(x[:1], total_bit_umap[:1]):
#     plt.text(a, b - 1500, b, ha='center', va='top', fontsize=10)
# for a, b in zip(x[:1], total_bit_pca[:1]):
#     plt.text(a, b + 2500, b, ha='center', va='top', fontsize=10)
# for a, b in zip(x[0:4], total_bit_codecs[0:4]):
#     plt.text(a, b + 1500, b, ha='center', va='bottom', fontsize=10)
# for a, b in zip(x[4:6], total_bit_codecs[4:6]):
#     plt.text(a, b - 2500, b, ha='center', va='bottom', fontsize=10)
# for a, b in zip(x[6:], total_bit_codecs[6:]):
#     plt.text(a, b + 1500, b, ha='center', va='bottom', fontsize=10)
# for a, b in zip(x, total_bit_lstm):
#     plt.text(a, b - 2500, b, ha='center', va='bottom', fontsize=10)
# plt.ylim([2000, 53000])
# plt.legend()
# plt.grid()
# plt.show()


# data_set_f = my_data.iloc[0:3000, 1:4].values
# training_set_f = my_data.iloc[0:2000, 1:4].values
# test_set_f = my_data.iloc[2000:3000, 1:4].values
# # x_simple = np.array([-2, -1, 0, 1, 2])
# # y_simple = np.array([4, 1, 3, 2, 0])
# # DPC = distancepearsoncorrelation(x_simple, y_simple)
# test_set_pca_f, eig_vec_f, test_set_reconstruction_f = pca(test_set_f, 2)
# # total_bit_codecs_f = [24000]
# # for m in threshold:
# #     bit = cal_transmission_bit(test_set_f, m, 'codecs')
# #     total_bit_codecs_f.append(bit)
# total_bit_codecs_f = [24000, 22092, 20328, 19872, 18864, 16656, 14640]
#
total_bit_umap_f = [16000, 16000, 16000, 16000, 16000, 16000, 16000]
total_bit_pca_f = [16144, 16144, 16144, 16144, 16144, 16144, 16144]
total_bit_lstm_f = list(map(round, (24000 * np.array([1, 0.9288, 0.712, 0.386, 0.268, 0.104, 0.037])).tolist()))
total_bit_codecs_f = list(map(round, (24000 * np.array([1, 0.794, 0.598, 0.404, 0.256, 0.204, 0.156])).tolist()))
# # total_bit_umap_f = cal_transmission_bit(test_set_pca_f, 0.1, 'umap')
# # total_bit_sae_f = cal_transmission_bit(test_set_pca_f, 0.1, 'sae')
# # total_bit_pca_f = cal_transmission_bit(test_set_pca_f, 0.1, 'pca')
plt.figure(2)
plt.plot(x, total_bit_umap_f, color = 'blue', marker='o', label = 'UMAP&SAE')
plt.plot(x, total_bit_pca_f, color = 'green', marker='o', label = 'PCA')
plt.plot(x, total_bit_codecs_f, color = 'red', marker='o', label = 'PD-Based Codecs')
plt.plot(x, total_bit_lstm_f, color = 'orange', marker='o', label = 'LSTM-Based Model')
plt.xticks(x, (0, 0.02, 0.05, 0.1, 0.15, 0.2, 0.3))
# plt.axis([-0.02, 0.3, 0, 1])
plt.title('Comparison of Transmission Bits for Force Signal')
plt.xlabel('Deadband Parameter')
plt.ylabel('Transmission Bits')
for a, b in zip(x[:1], total_bit_umap_f[:1]):
    plt.text(a, b - 1500, b, ha='center', va='top', fontsize=10)
for a, b in zip(x[:1], total_bit_pca_f[:1]):
    plt.text(a, b + 1500, b, ha='center', va='top', fontsize=10)
for a, b in zip(x[0:3], total_bit_lstm_f[0:3]):
    plt.text(a, b + 500, b, ha='center', va='bottom', fontsize=10)
for a, b in zip(x[0:3], total_bit_codecs_f[0:3]):
    plt.text(a, b - 1500, b, ha='center', va='bottom', fontsize=10)
for a, b in zip(x[3:4], total_bit_lstm_f[3:4]):
    plt.text(a, b - 1500, b, ha='center', va='bottom', fontsize=10)
for a, b in zip(x[3:4], total_bit_codecs_f[3:4]):
    plt.text(a, b + 500, b, ha='center', va='bottom', fontsize=10)
for a, b in zip(x[4:5], total_bit_lstm_f[4:5]):
    plt.text(a, b + 500, b, ha='center', va='bottom', fontsize=10)
for a, b in zip(x[4:5], total_bit_codecs_f[4:5]):
    plt.text(a, b - 1500, b, ha='center', va='bottom', fontsize=10)
for a, b in zip(x[5:], total_bit_lstm_f[5:]):
    plt.text(a, b - 1500, b, ha='center', va='bottom', fontsize=10)
for a, b in zip(x[5:], total_bit_codecs_f[5:]):
    plt.text(a, b + 500, b, ha='center', va='bottom', fontsize=10)
# plt.text(x[-1], total_bit_codecs_f[-1] - 500, total_bit_codecs_f[-1], ha='center', va='bottom', fontsize=10)
plt.legend()
plt.grid()
plt.show()
