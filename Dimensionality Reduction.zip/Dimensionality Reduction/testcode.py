import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


my_data = pd.read_table('texture - LU - sliding - output.txt', sep=' ')
real_v = my_data.iloc[2000:3000, 1:4].values
# #
#
v_total = pd.concat((my_data.iloc[0:2000, 1:4], my_data.iloc[2000:3000, 1:4]), axis = 0)

# v_total_z = pd.concat((my_data.iloc[0:1000, 3:4], my_data.iloc[1000:2000, 3:4]), axis = 0)

inputs_v = v_total[len(v_total) - len(real_v) - 60:].values
a = inputs_v[60:, 0:2]
b = np.append(inputs_v[60:, 0:2], inputs_v[60:, 0:1], axis=1)