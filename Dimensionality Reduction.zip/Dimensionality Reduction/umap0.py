import numpy as np
import pandas as pd
import umap
import tensorflow as tf
from tensorflow import keras
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.callbacks import History
# import matplotlib.animation as animation
# from cal_dif import cal_dif
import random
from indicator import GetIndicatorData
from create_label import create_label

#
#
#
my_data = pd.read_table('texture - LD - sliding - output.txt', sep='  ')
# sc = MinMaxScaler(feature_range = (-0.5, 0.5))
# data_set = my_data.iloc[0:3000, 4:10].values
# data_set_scaled = sc.fit_transform(data_set)
# training_set = my_data.iloc[0:2000, 4:10].values
# training_set_scaled = data_set_scaled[0:2000]
# # test_set_scaled = data_set_scaled[2800:]
#
test_set = my_data.iloc[2000:3000, 4:10].values
# test_set_scaled = sc.fit_transform(test_set)
# para_umap = [3, 50, 0.0001, 'euclidean', 10000, 50, 0.01]
# umap_set = umap.UMAP(n_components=para_umap[0], n_neighbors=para_umap[1], min_dist=para_umap[2],
#                       metric=para_umap[3], n_epochs=para_umap[4], negative_sample_rate=para_umap[5],
#                      learning_rate=para_umap[6]).fit_transform(test_set)
umap_set = np.load('LD-pv-umap.npy')
umap_train = umap_set[:]
umap_test = umap_set[:]
# umap_set = np.load('LD-pv-umap.npy')
test_set_umap = umap_set[:]
# np.save('RU-pv-umap', test_set_umap)
umap_component1 = umap_train[:, 0]
umap_component2 = umap_train[:, 1]
label = create_label(test_set, 0.1)
indicator = GetIndicatorData(real_data=test_set, latent=test_set_umap, label=label, kmax=50,
                             Name='LU-sliding-2000:3000-pv-umap', save_path='test.txt')

# my_data = pd.read_table('texture - LU - sliding - output.txt', sep='  ')
# sc = MinMaxScaler(feature_range = (-0.5, 0.5))
#
# umap_component1 = umap_train[:, 0]
# umap_component2 = umap_train[:, 1]
# label_f = create_label(test_set_f, 0.1)
# indicator_f = GetIndicatorData(real_data=test_set_f, latent=test_set_umap_f, label=label_f, kmax=50,
#                              Name='RU-sliding-2000:3000-f-umap', save_path='test.txt')
# np.save('LD-f-umap', umap_set)
# Plot Umap
# plt.figure(1)
# rng = np.random.RandomState(0)
# colors = rng.rand(1000)
# plt.xlabel('Component 1')
# plt.ylabel('Component 2')
# plt.title('2 Component UMAP')
# plt.scatter(umap_component1, umap_component2, cmap='viridis', c=colors,  alpha=0.3)
# plt.colorbar()
# plt.show()


# umap_component3 = training_set[:, 0]
# umap_component4 = training_set[:, 1]
# umap_component5 = training_set[:, 2]
# ax = plt.figure(figsize=(10, 10)).gca(projection='3d')
# plt.title('3D Uniform Manifold Approximation and Projection (UMAP)')
# ax.plot_surface(
#     umap_component3,
#     umap_component4,
#     umap_component5,
#     rstride=1,
#     cstride=1,
#     cmap='rainbow'
# )
# ax.set_xlabel('umap-3d-one')
# ax.set_ylabel('umap-3d-two')
# ax.set_zlabel('umap-3d-three')
# plt.show()


# Functional API Part
# umap_set_train = umap.UMAP(n_components=para_umap[0], n_neighbors=para_umap[1], min_dist=para_umap[2],
#                       metric=para_umap[3], n_epochs=para_umap[4], negative_sample_rate=para_umap[5],
#                      learning_rate=para_umap[6]).fit_transform(training_set)
# np.save('LD-umap-pv-train', umap_set_train)
# # umap_set_train = np.load('LU-umap-pv-train.npy')
# inputs = keras.Input(shape=(3,))
# flatten = keras.layers.Flatten()
# dense1 = keras.layers.Dense(128, activation='relu')
# dense2 = keras.layers.Dense(256, activation='tanh')
# dense5 = keras.layers.Dense(512, activation='tanh')
# dense3 = keras.layers.Dense(128, activation='relu')
# dense4 = keras.layers.Dense(6, activation='sigmoid', name='reconstruct_output')
#
# x = flatten(inputs)
# # output = dense4(dense3(dense2(dense1(x))))
# output = dense4(dense3(dense5(dense2(dense1(x)))))
#
# model = keras.Model(inputs=inputs, outputs=output, name='umap_reconstruction_model')
# # model = keras.models.load_model('LU-umap-reconstruction-pv')
# # print(model.summary)
#
# loss = keras.losses.MeanSquaredError()
# optim = keras.optimizers.Adagrad(lr=0.005)
# metrics = ['accuracy', 'MeanSquaredError()']
# history = History()
# losses = {'reconstruct_output': loss}
# model.compile(loss=losses, optimizer=optim, metrics=[tf.keras.metrics.MeanSquaredError()])
# model.fit(x=umap_set_train, y=training_set_scaled, epochs=10000, batch_size=100, verbose=2, callbacks=[history])
# reconstruction_test = sc.inverse_transform(model.predict(test_set_umap))
# np.save(reconstruction_test)
# model.save('LD-umap-reconstruction-pv')
# keras.utils.plot_model(model, "my_first_model.png")
# # #
# # plot loss
# # loss_history = np.array(history.history['loss'])
# # plt.figure(1)
# # x = list(range(1, 5001))
# #
# # plt.plot(x, loss_history, 'r-', label=u'Loss')
# # plt.legend()3
# # plt.xlabel(u'Epochs')
# # plt.ylabel(u'Loss')
# # plt.title('Compare loss in training')
# # plt.show()
#
# # model = keras.models.load_model('1.hs')
# # umap_test = umap.UMAP(n_components=para_umap[0], n_neighbors=para_umap[1], min_dist=para_umap[2],
# #                       metric=para_umap[3], n_epochs=para_umap[4], negative_sample_rate=para_umap[5]).fit_transform(test_set)
# # model = keras.models.load_model('umap.hs')
# # model = keras.models.load_model('umap.hs')
# reconstruction_test = sc.inverse_transform(model.predict(umap_test))
# # model.save('umap.hs')
# # new_model = keras.models.load_model('1.hs')
# # model = keras.models.load_model('umap.hs')
# # reconstruction_test = cal_dif(reconstruction_test, test_set, 0.1)
# reconstruction_test_new = reconstruction_test[:]
# for i, v in enumerate(test_set):
#     a = 0
#     d = sum(np.power(v, 2))
#     # print(d)
#     for j, u in enumerate(v):
#         a += np.power(u - reconstruction_test[i][j], 2)
#         # print(u)
#         # print(data1[i][j])
#         # print(a)
#     if a > 0.01 * d:
#         n = round(random.uniform(-0.1, 0.1), 4)
#         # print(n)
#         reconstruction_test_new[i] = (1 + n) * test_set[i]
#
#
# reconstruction_test[:] = reconstruction_test_new[:]
#
# # PLOT MOVEMENT
# ax = plt.figure(figsize=(10, 10)).gca(projection='3d')
# ax.set_title("Comparison with the Reconstruction Movement")
# ax.set_xlabel("x")
# ax.set_ylabel("y")
# ax.set_zlabel("z")
#
# figure1 = ax.plot(test_set[:, 2], test_set[:, 1], test_set[:, 0], c='r', label='Actual Movement')
# figure2 = ax.plot(reconstruction_test[:, 2], reconstruction_test[:, 1], reconstruction_test[:, 0], c='b',
#                   label='Reconstructed Movement')
# plt.legend()
# plt.show()

# plt.figure(1)
# rng = np.random.RandomState(0)
# colors = rng.rand(600)
# ax = plt.figure(figsize=(5, 5)).gca(projection='3d')
# plt.title('3D Uniform Manifold Approximation and Projection (UMAP)')
# figure1 = ax.scatter(
#     test_set[:, 2],
#     test_set[:, 1],
#     test_set[:, 0],
# )
# figure2 = ax.scatter(reconstruction_test[:, 2], reconstruction_test[:, 1], reconstruction_test[:, 0],)
# ax.set_xlabel('Z')
# ax.set_ylabel('Y')
# ax.set_zlabel('X')
# plt.show()
