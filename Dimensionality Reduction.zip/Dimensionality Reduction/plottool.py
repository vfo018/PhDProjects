import tool
import numpy as np
import pandas as pd
# import umap
# import umap.plot
# import tensorflow as tf
from tensorflow import keras
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.callbacks import History
# import matplotlib.animation as animation
# from cal_dif import cal_dif
import random
from indicator import GetIndicatorData
from create_label import create_label
# import torch
# import torch.nn as nn
# import torch.nn.parallel
# import torch.optim as optim
# import torch.utils.data
# from torch.autograd import Variable
# from indicator import GetIndicatorData
from PCA import pca

my_data = pd.read_table('texture - LU - sliding - output.txt', sep='  ')
sc = MinMaxScaler(feature_range = (-0.5, 0.5))
data_set = my_data.iloc[0:3000, 1:4].values
data_set_scaled = sc.fit_transform(data_set)
training_set = my_data.iloc[0:2000, 1:4].values
training_set_scaled = data_set_scaled[0:2000]
test_set = my_data.iloc[2000:3000, 1:4].values
label_f = create_label(test_set, 0.1)
umap_set = np.load('LU-f-umap.npy')
test_set_pca_f, eig_vec_f, test_set_reconstruction_f = pca(test_set, 2)
test_embedding = np.load('LU-f-sae.npy')
gifPloterLatentTrain = tool.GIFPloter()
a = gifPloterLatentTrain.AddNewFig(
    test_set_pca_f,
    label_f,
    his_loss=None,
    graph=None,
    link=None,
    title_='pca_f_v2.png')


