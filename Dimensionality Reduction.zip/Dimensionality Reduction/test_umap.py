import numpy as np
import pandas as pd
import umap
import tensorflow as tf
from tensorflow import keras
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.callbacks import History
import matplotlib.animation as animation
# from cal_dif import cal_dif
import random


inputs = keras.Input(shape=(3,))
flatten = keras.layers.Flatten()
dense1 = keras.layers.Dense(128, activation='relu')
dense2 = keras.layers.Dense(256, activation='tanh')
dense5 = keras.layers.Dense(512, activation='tanh')
dense3 = keras.layers.Dense(128, activation='relu')
dense4 = keras.layers.Dense(6, activation='sigmoid', name='reconstruct_output')

x = flatten(inputs)
# output = dense4(dense3(dense2(dense1(x))))
output = dense4(dense3(dense5(dense2(dense1(x)))))

model = keras.Model(inputs=inputs, outputs=output, name='umap_reconstruction_model')
keras.utils.plot_model(model, "my_first_model.png", show_shapes=True)
