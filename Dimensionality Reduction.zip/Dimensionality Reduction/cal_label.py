import numpy as np


def cal_label(data1, data2, threshold):
    label = []
    for i, v in enumerate(data1):
        a = 0
        d = sum(np.power(v, 2))
        # print(d)
        for j, u in enumerate(v):
            a += np.power(u - data2[i][j], 2)
            # print(u)
            # print(data2[i][j])
            # print(a)
        if a <= threshold * d:
            label.append(1)
        elif v[0] == 0 and v[1] == 0:
            label.append(1)
        else:
            label.append(-1)
        # print(a)
    return label


a = np.array([[-0.23228, -1.79036, 0.95964], [-0.02524, -0.74627, 1.02659], [-0.06632, 0.36381, 1.09037]])
b = np.array([[-0.29827, -1.76543, 1.14261], [-0.09559, -0.71970, 1.22167], [0.09992, 0.30102, 0.62942]])
l = cal_label(b, a, 0.1)
