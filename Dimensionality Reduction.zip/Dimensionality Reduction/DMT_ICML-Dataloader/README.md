# DMT Code

This is a PyTorch implementation of DMT for the paper "Deep Manifold Transformation Using Crossing-Layer Geometry-Presering Constrains". 

## Protect Ideas

The code is submitted to ICML 2021 as part of the supplementary and should be used for the review purpose only. The reviewers who receive the code have the responsibility to protect the confidentiality of the code, that is:
* should not show the code to anyone else, including colleagues or students, unless you have asked them to write a review, or to help with your review;
* should not use ideas or code from the paper to develop your own ideas and code;
* should erase any code that the authors submitted as part of the supplementary, and any implementations you have written to evaluate the ideas in the papers, as well as any results of those implementations.

## Requirements

* pytorch == 1.7.1
* scipy == 1.4.1
* numpy == 1.18.5
* scikit-learn == 0.21.3
* csv == 1.0
* matplotlib == 3.1.1
* imageio == 2.6.0

## Running the code
```
python main.py # for DMT
```

The results are saved in ./log/ .
