# import loaddata.dataloader_mnist as  dataloader_mnist
import loaddata.dataloader_mnist as  dataloader_mnist
import torch
from sklearn.metrics import pairwise_distances
import numpy as np
from loaddata.sigma import PoolRunner
import scipy
from sklearn.preprocessing import StandardScaler
from pynndescent import NNDescent
import torchvision.datasets as datasets

class CIFARSUB(dataloader_mnist.MNIST):
    # def __init__(
    #     self,
    #     n_point,
    #     random_state=1,
    #     root='data/',
    #     train=True,
    #     trans=None,
    #     perplexity=None,
    #     v_input=100,
    #     device=None,
    #     func_new=None,
    # ):
        # super(SWISSROLL, self).__init__(
        #     n_point=n_point,
        #     random_state=random_state,
        #     root=root,
        #     train=train,
        #     trans=trans,
        #     perplexity=perplexity,
        #     v_input=v_input,
        #     device=device,
        #     func_new=func_new,
        # )


    def _LoadData(self):
        print('load CIFAR sub dataset')
        if not self.train:
            random_state = self.random_state + 1

        dataloader = datasets.CIFAR10(
            root="./data", train=self.train, download=True, transform=None
        )
        self.data = dataloader.data[:self.n_point] / 255
        self.label = np.array(dataloader.targets[:self.n_point])
        bool_index = (self.label==0).astype(np.int32)+(self.label==4).astype(np.int32)+(self.label==8).astype(np.int32)
        # print(bool_index)
        # input()
        self.data = self.data[bool_index>0]
        self.label = self.label[bool_index>0]
        print(self.data.shape)
        self.inputdim = self.data[0].shape
        
        # self.data = StandardScaler().fit_transform(data[0])
        # self.label = data[1]

        # from sklearn.decomposition import PCA
        # import tool
        # # emb = PCA().fit_transform(data)
        # import matplotlib.pyplot as plt
        # fig = plt.figure(figsize=(5, 5))
        
        # ax = fig.add_subplot(1,1,1,projection='3d')

        # ax.scatter(self.data[:, 0],
        #                self.data[:, 1],
        #                self.data[:, 2],
        #                c=self.label,
        #                s=10,
        #                cmap='rainbow')
        # plt.savefig('ddddd.png', dpi=400)

        self.inputdim = self.data[0].shape