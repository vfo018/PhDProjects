import torch

class My_Loader():
    def __init__(self, batch_size, num_data) -> None:
        super().__init__()
        self.batch_size = batch_size
        self.num_data = num_data
        self.reset()

    def reset(self,):
        self.index_all = torch.randperm(self.num_data)
        self.c_use = 0
        self.c_use_end = 1
        self.batch_idx = 0
        self.c_use_end = min(self.c_use+self.batch_size, self.num_data)

    def epochend(self):
        return self.c_use!=self.c_use_end

    def load(self,):
        
        index = self.index_all[self.c_use:self.c_use_end]
        self.c_use = self.c_use_end
        self.c_use_end = min(self.c_use+self.batch_size, self.num_data)
        self.batch_idx += 1
        return self.batch_idx-1, index
