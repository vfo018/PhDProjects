import random
from loaddata import dataloader_mnist
import torch
import torchvision.datasets as datasets
# from sklearn.datasets import make_s_curve
from sklearn.metrics import pairwise_distances
import numpy as np
from loaddata.sigma import PoolRunner
import scipy
from sklearn.preprocessing import StandardScaler
from pynndescent import NNDescent

class MNISTSUB0(dataloader_mnist.MNIST):
    # def __init__(
    #     self,
    #     n_point,
    #     random_state=1,
    #     root='data/',
    #     train=True,
    #     trans=None,
    #     perplexity=None,
    #     v_input=100,
    #     device=None,
    #     func_new=None
    # ):
    #     super(SCURVE, self).__init__(
    #         n_point=n_point,
    #         random_state=random_state,
    #         root=root,
    #         train=train,
    #         trans=trans,
    #         perplexity=perplexity,
    #         v_input=v_input,
    #         device=device,
    #         func_new=func_new,
    #     )


    def _LoadData(self):

        print('load mnist dataset')
        dataloader = datasets.MNIST(
            root="./data", train=self.train, download=True, transform=None
        )
        
        self.data = dataloader.data[:self.n_point].float() / 255
        self.label = dataloader.targets[:self.n_point]
        
        delay_list = []
        index_numpy = np.arange(start=0,stop=60000)
        for i in range(1, 2):
            index_all = list(index_numpy[self.label==(i)])
            a = random.sample(index_all, len(index_all)*1//2)
            delay_list += a
        
        self.data  = np.delete(self.data, delay_list, axis=0)
        print(self.data.shape)
        self.label = np.delete(self.label, delay_list, axis=0)
        self.inputdim = self.data[0].shape
