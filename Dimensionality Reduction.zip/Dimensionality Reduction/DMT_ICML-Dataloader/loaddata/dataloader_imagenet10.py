# import loaddata.dataloader_mnist as  dataloader_mnist
import loaddata.dataloader_mnist as  dataloader_mnist
import torch
from sklearn.metrics import pairwise_distances
import numpy as np
from loaddata.sigma import PoolRunner
import scipy
from sklearn.preprocessing import StandardScaler
from pynndescent import NNDescent
import torchvision.datasets as datasets
from PIL import Image

class CIFARSUB(dataloader_mnist.MNIST):
    # def __init__(
    #     self,
    #     n_point,
    #     random_state=1,
    #     root='data/',
    #     train=True,
    #     trans=None,
    #     perplexity=None,
    #     v_input=100,
    #     device=None,
    #     func_new=None,
    # ):
        # super(SWISSROLL, self).__init__(
        #     n_point=n_point,
        #     random_state=random_state,
        #     root=root,
        #     train=train,
        #     trans=trans,
        #     perplexity=perplexity,
        #     v_input=v_input,
        #     device=device,
        #     func_new=func_new,
        # )


    def _LoadData(self):
        print('load IMAGESUB dataset')
        if not self.train:
            random_state = self.random_state + 1

        path = "data/train_labeled_10class_0123_8081_154155_404_407.txt"
        pathImage = "/usr/commondata/public/ImageNet/ILSVRC2012/train/"
        path_txt = open(path, "r").read().split("\n")

        data = np.zeros((len(path_txt), 48, 48, 3,))
        label = []
        i = 0
        for txt in path_txt:
            if len(txt) > 4:
                pathI = txt.split(" ")[0]
                img = np.array(
                    Image.open(pathImage + pathI).convert("RGB").resize((48, 48))
                    )
                data[i] = img
                i += 1
                label.append(int(txt.split(" ")[1]))

        self.data = data/255
        self.label = np.array(label)
        print(self.data.shape)
        self.inputdim = self.data[0].shape
        
        # self.data = StandardScaler().fit_transform(data[0])
        # self.label = data[1]

        # from sklearn.decomposition import PCA
        # import tool
        # # emb = PCA().fit_transform(data)
        # import matplotlib.pyplot as plt
        # fig = plt.figure(figsize=(5, 5))
        
        # ax = fig.add_subplot(1,1,1,projection='3d')

        # ax.scatter(self.data[:, 0],
        #                self.data[:, 1],
        #                self.data[:, 2],
        #                c=self.label,
        #                s=10,
        #                cmap='rainbow')
        # plt.savefig('ddddd.png', dpi=400)

        self.inputdim = self.data[0].shape