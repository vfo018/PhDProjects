from loaddata import dataloader_mnist
import torch
from sklearn.datasets import make_s_curve
from sklearn.metrics import pairwise_distances
import numpy as np
from loaddata.sigma import PoolRunner
import scipy
from sklearn.preprocessing import StandardScaler
from pynndescent import NNDescent
import scanpy as sc
import numpy as np 
import anndata

class SMILE(dataloader_mnist.MNIST):
    # def __init__(
    #     self,
    #     n_point,
    #     random_state=1,
    #     root='data/',
    #     train=True,
    #     trans=None,
    #     perplexity=None,
    #     v_input=100,
    #     device=None,
    #     func_new=None
    # ):
    #     super(SCURVE, self).__init__(
    #         n_point=n_point,
    #         random_state=random_state,
    #         root=root,
    #         train=train,
    #         trans=trans,
    #         perplexity=perplexity,
    #         v_input=v_input,
    #         device=device,
    #         func_new=func_new,
    #     )


    def _LoadData(self):
        print('load SCURVE dataset')
        if not self.train:
            random_state = self.random_state + 1

        adata=sc.read('data/smile9dim.h5ad')
        scaler = StandardScaler()
        adata.X=scaler.fit_transform(adata.X)
        data=torch.tensor(adata.X)
        
        c = list(adata.obs['color'])
        cset = list(set(c))
        cset.sort()
        print(cset)
        l = []
        for citem in c:
            l.append(cset.index(citem))

        # from sklearn.decomposition import PCA
        # import tool
        # emb = PCA().fit_transform(data)
        # gp = tool.GIFPloter()
        # gp.AddNewFig(emb,np.array(l),title_='ggg.png')
        self.data = data
        self.label = np.array(l)
        self.inputdim = self.data[0].shape
