from loaddata import dataloader_coil20
from tkinter.messagebox import NO
import loaddata.dataloader_swishroll as dataloader_swishroll
import loaddata.dataloader_scurve as dataloader_scurve
import loaddata.dataloader_digits as dataloader_digits
import loaddata.dataloader_mnist as dataloader_mnist
import loaddata.dataloader_coil20 as dataloader_coil20
import loaddata.dataloader_coil100 as dataloader_coil100
import loaddata.dataloader_spheres5500 as dataloader_spheres5500
import loaddata.dataloader_spheres10000 as dataloader_spheres10000
import torchvision.transforms as transforms
import torch
import loaddata.dataloader as myDataloader


def Getdataloader(
    data_name,
    n_point,
    batch_size,
    perplexity=None,
    num_workers=1,
    sampler=None,
    random_state=1,
    device=None,
    tocuda=True,
    K=15,
    epsilon=2,
    func_new=None
    ):
    
    trans = transforms.Compose(
        [transforms.ToTensor()]
    )
  
    if data_name == 'swishroll':
        dataset = dataloader_swishroll.SWISSROLL(
            n_point=n_point,
            random_state=random_state,
            trans=trans,
            perplexity=perplexity,
            device=device,
            func_new=func_new,
            )
    if data_name == 'scurve':
        dataset = dataloader_scurve.SCURVE(
            n_point=n_point,
            random_state=random_state,
            trans=trans,
            perplexity=perplexity,
            device=device,
            func_new=func_new,
            )
    if data_name == 'digits':
        dataset = dataloader_digits.DIGITS(
            n_point=n_point,
            random_state=random_state,
            trans=trans,
            perplexity=perplexity,
            device=device,
            func_new=func_new,
            )
    if data_name == 'spheres5500':
        dataset = dataloader_spheres5500.Spheres5500(
            n_point=n_point,
            random_state=random_state,
            trans=trans,
            perplexity=perplexity,
            device=device,
            func_new=func_new,
            )
    if data_name == 'spheres10000':
        dataset = dataloader_spheres10000.Spheres10000(
            n_point=n_point,
            random_state=random_state,
            trans=trans,
            perplexity=perplexity,
            device=device,
            func_new=func_new,
            )
    if data_name == 'mnist':
        dataset = dataloader_mnist.MNIST(
            n_point=n_point,
            random_state=random_state,
            trans=trans,
            perplexity=perplexity,
            device=device,
            func_new=func_new,
            )
    if data_name == 'coil20':
        dataset = dataloader_coil20.COIL20(
            n_point=n_point,
            random_state=random_state,
            trans=trans,
            perplexity=perplexity,
            device=device,
            func_new=func_new,
            )
    if data_name == 'coil100':
        dataset = dataloader_coil100.COIL100(
            n_point=n_point,
            random_state=random_state,
            trans=trans,
            perplexity=perplexity,
            device=device,
            func_new=func_new,
            )
    dataset._LoadData()
    dataset._PretreatmentMaskAndDistance(K=K, epsilon=epsilon)
    dataset.label = torch.tensor(dataset.label)
    
    if tocuda:
        dataset.data = torch.tensor(dataset.data).to(device).float()
        dataset.label = torch.tensor(dataset.label).to(device)
    # loader = torch.utils.data.DataLoader(
    #     dataset,
    #     batch_size=batch_size,
    #     shuffle=True,
    #     num_workers=num_workers,
    #     sampler=sampler,
    #     pin_memory=True,
    #     )
    loader = myDataloader.My_Loader(
        batch_size=batch_size,
        num_data=dataset.data.shape[0]
        )


    return loader, dataset