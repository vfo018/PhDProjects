from loaddata import dataloader_cifa_sub, dataloader_coil20, dataloader_smileplus
from tkinter.messagebox import NO
import loaddata.dataloader_swishroll as dataloader_swishroll
import loaddata.dataloader_scurve as dataloader_scurve
import loaddata.dataloader_digits as dataloader_digits
import loaddata.dataloader_fmnist as dataloader_fmnist
import loaddata.dataloader_mnist as dataloader_mnist
import loaddata.dataloader_mnistsub0 as dataloader_mnist_sub0
import loaddata.dataloader_coil20 as dataloader_coil20
import loaddata.dataloader_coil100 as dataloader_coil100
import loaddata.dataloader_spheres5500 as dataloader_spheres5500
import loaddata.dataloader_imagenet10 as dataloader_imagenet10
import loaddata.dataloader_spheres10000 as dataloader_spheres10000
import loaddata.dataloader_toy_duplicate as dataloader_toy_duplicate
import loaddata.dataloader_toy_diff_std as dataloader_toy_diff_std
import loaddata.dataloader_cifa as dataloader_cifa
import loaddata.dataloader_sumsink as dataloader_sumsink
import loaddata.dataloader_smileplus as dataloader_smileplus
import loaddata.dataloader_smile as dataloader_smile
import loaddata.dataloader_yj as dataloader_yj
import loaddata.dataloader_googleword as dataloader_googleword
import loaddata.dataloader_PBMC as dataloader_PBMC
import torchvision.transforms as transforms
import torch
import os
import joblib
import loaddata.dataloader as myDataloader
import numpy as np

def Getdataloader(
    data_name,
    n_point,
    batch_size,
    perplexity=None,
    num_workers=1,
    sampler=None,
    random_state=1,
    device=None,
    tocuda=True,
    func_new=None,
    v_input=100,
    same_sigma=None,
    metric="euclidean",
    train=True,
    ):
    
    trans = transforms.Compose(
        [transforms.ToTensor()]
    )
  
    if data_name == 'swishroll':
        F = dataloader_swishroll.SWISSROLL
    if data_name == 'scurve':
        F = dataloader_scurve.SCURVE
    if data_name == 'digits':
        F = dataloader_digits.DIGITS
    if data_name == 'spheres5500':
        F = dataloader_spheres5500.Spheres5500
    if data_name == 'spheres10000':
        F = dataloader_spheres10000.Spheres10000
    if data_name == 'mnist':
        F = dataloader_mnist.MNIST
    if data_name == 'mnistsub0':
        F = dataloader_mnist_sub0.MNISTSUB0
    if data_name == 'fmnist':
        F = dataloader_fmnist.FMNIST    
    if data_name == 'coil20':
        F = dataloader_coil20.COIL20
    if data_name == 'coil100':
        F = dataloader_coil100.COIL100
    if data_name == 'toy_duplicate':
        F = dataloader_toy_duplicate.Duplicate
    if data_name == 'toy_diff_std':
        F = dataloader_toy_diff_std.DiffStd
    if data_name == 'yj01':
        F = dataloader_yj.YJ01
    if data_name == 'cifa10':
        F = dataloader_cifa.CIFAR
    if data_name == 'cifa10sub':
        F = dataloader_cifa_sub.CIFARSUB
    if data_name == 'smile':
        F = dataloader_smile.SMILE
    if data_name == 'smilepluse':
        F = dataloader_smileplus.SMILE
    if data_name == 'sumsink':
        F = dataloader_sumsink.SUMSINK
    if data_name == 'pbmc':
        F = dataloader_PBMC.PBMC
    if data_name == 'googleword':
        F = dataloader_googleword.WORDVECTOR
    if data_name == 'imagenet10':
        F = dataloader_imagenet10.CIFARSUB

    dataset = F(
        n_point=n_point,
        random_state=random_state,
        trans=trans,
        perplexity=perplexity,
        device=device,
        func_new=func_new,
        v_input=v_input,
        same_sigma=same_sigma,
        metric=metric,
        train=train
        )

    loadpath = 'save/sDATA_npoint{}_data_name{}_metric{}_same_sigma{}_vinput{}_Q{}_train{}.pkl'.format(
        n_point, data_name, metric, same_sigma, v_input,perplexity,train)
    

    
    
    if os.path.exists(loadpath):
        [
            dataset.data,
            dataset.label,
            dataset.sigma,
            dataset.rho,
        ] = joblib.load(loadpath)
        dataset.inputdim=dataset.data[0].shape

        print('load', loadpath, dataset.data.shape)
    else:
        dataset._LoadData()
        
        if data_name != 'googleword':
            dataset._Pretreatment()
        else:
            dataset.sigma = np.zeros(dataset.data.shape[0])+1
            dataset.rho = np.zeros(dataset.data.shape[0])
        joblib.dump(
            [
                dataset.data,
                dataset.label,
                dataset.sigma,
                dataset.rho,
            ], loadpath)
        print('save', loadpath)
    if tocuda:
        dataset.data = torch.tensor(dataset.data).to(device).float()
        dataset.rho = torch.tensor(dataset.rho).to(device).float()
        dataset.sigma = torch.tensor(dataset.sigma).to(device).float()
        dataset.label = torch.tensor(dataset.label).to(device)

    loader = myDataloader.My_Loader(
        batch_size=batch_size,
        num_data=dataset.data.shape[0]
        )

    return loader, dataset