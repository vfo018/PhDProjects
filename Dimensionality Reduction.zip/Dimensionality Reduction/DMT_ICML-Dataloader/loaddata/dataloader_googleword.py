import random
from loaddata import dataloader_mnist
import torch
import torchvision.datasets as datasets
# from sklearn.datasets import make_s_curve
from sklearn.metrics import pairwise_distances
import numpy as np
from loaddata.sigma import PoolRunner
import scipy
from sklearn.preprocessing import StandardScaler
from pynndescent import NNDescent
# from gensim.test.utils import lee_corpus_list
# import gensim

class WORDVECTOR(dataloader_mnist.MNIST):
    # def __init__(
    #     self,
    #     n_point,
    #     random_state=1,
    #     root='data/',
    #     train=True,
    #     trans=None,
    #     perplexity=None,
    #     v_input=100,
    #     device=None,
    #     func_new=None
    # ):
    #     super(SCURVE, self).__init__(
    #         n_point=n_point,
    #         random_state=random_state,
    #         root=root,
    #         train=train,
    #         trans=trans,
    #         perplexity=perplexity,
    #         v_input=v_input,
    #         device=device,
    #         func_new=func_new,
    #     )


    def _LoadData(self):

        print('load wordvector dataset')
        # model = gensim.models.KeyedVectors.load_word2vec_format('data/googlenews/GoogleNews-vectors-negative300.bin.gz', binary=True)
        # # model = Word2Vec(lee_corpus_list, vector_size=24, epochs=100)
        # model.wv.save_word2vec_format("./vectors.txt", binary=False)
        # path = ''
        f = open('data/googlenews/vectors.txt')
        line = f.readline()
        data = np.zeros((200000,300))
        
        i=0
        while line:
            dataitem = []
            # print('---',line)
            if len(line.split(' '))>20:
                if '</s> ' in line:
                    line = line.split('</s> ')[1]
                # print('------',line)
                for l in line.split(' ')[-300:]:
                    try:
                        dataitem.append(float(l))
                    except:
                        pass
                print(len(dataitem))
                data[i] = np.array(dataitem)
                
                i += 1
                if i % 10000 == 0:
                    print(i, len(dataitem))
                if i % 200000 == 0:
                    break
            line = f.readline()
        f.close()

        print(data)
        self.data  = data
        print(self.data.shape)
        self.label = np.array(range(self.data.shape[0]))
        self.inputdim = self.data[0].shape
