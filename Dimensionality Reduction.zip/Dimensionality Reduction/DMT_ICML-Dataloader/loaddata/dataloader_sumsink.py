from loaddata import dataloader_mnist
import torch
from sklearn.datasets import make_s_curve
from sklearn.metrics import pairwise_distances
import numpy as np
from loaddata.sigma import PoolRunner
import scipy
from sklearn.preprocessing import StandardScaler
from pynndescent import NNDescent
import scanpy as sc
import numpy as np 
import anndata
import pandas as pd 
import scanpy as sc
import numpy as np
import anndata


class SUMSINK(dataloader_mnist.MNIST):
    # def __init__(
    #     self,
    #     n_point,
    #     random_state=1,
    #     root='data/',
    #     train=True,
    #     trans=None,
    #     perplexity=None,
    #     v_input=100,
    #     device=None,
    #     func_new=None
    # ):
    #     super(SCURVE, self).__init__(
    #         n_point=n_point,
    #         random_state=random_state,
    #         root=root,
    #         train=train,
    #         trans=trans,
    #         perplexity=perplexity,
    #         v_input=v_input,
    #         device=device,
    #         func_new=func_new,
    #     )


    def _LoadData(self):
        print('load samusik_01 dataset')
        Samusik01=pd.read_csv("data/sumsink/samusik_01.csv")
        Samusik01=Samusik01.drop(columns=['Unnamed: 0'])  #86864x38
        label=pd.read_csv("data/sumsink/samusik01_labelnr.csv").drop(columns=['Unnamed: 0'])
        celltype=pd.read_csv("data/sumsink/samusik01_labelnr_celltype.csv")
        celltype=celltype['name'].values.tolist()
        celltype_dict=dict(zip(list(range(1,25)),celltype))
        #label celltype se samusik_01labelnr_celltype.csv
        sadata=anndata.AnnData(X=Samusik01.values)

        # #2021-1-20 test do PCA before DMT
        # sc.pp.pca(sadata)  #sadata.obsm['X_pca'].shape  (86864, 37)

        #if not do PCA, use Samusik01.values to obsm X_pca
        # sadata.obsm['X_pca']=Samusik01.values  #not pca, but use this form

        sadata.obs['celltype']=label.x.values
        sadata.obs.replace({"celltype":celltype_dict},inplace=True) 
        sadata.obs['label']=  [str(i) for i in label.x]
        bool1 = sadata.obs['label']!='0'
        sadata=sadata[bool1]  #subset, get 53173 × 38
        # from sklearn.preprocessing import StandardScaler
        # scaler = StandardScaler()
        # sadata.X=scaler.fit_transform(sadata.X)
        sc.pp.pca(sadata)
    
        data_train=torch.tensor(sadata.obsm['X_pca'].copy())
        label_train=torch.tensor(label.values[bool1])

        # from sklearn.decomposition import PCA
        # import tool
        # emb = PCA().fit_transform(data)
        # gp = tool.GIFPloter()
        # gp.AddNewFig(emb,np.array(l),title_='ggg.png')
        self.data = data_train
        self.label = label_train
        self.inputdim = self.data[0].shape
