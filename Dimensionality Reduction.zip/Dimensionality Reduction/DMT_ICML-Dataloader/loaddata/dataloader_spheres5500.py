from loaddata import dataloader_mnist
import torch
from sklearn.datasets import make_swiss_roll
from sklearn.metrics import pairwise_distances
import numpy as np
from loaddata.sigma import PoolRunner
import scipy
from sklearn.preprocessing import StandardScaler
from pynndescent import NNDescent
import os
from PIL import Image

class Spheres5500(dataloader_mnist.MNIST):
    # def __init__(
    #     self,
    #     n_point,
    #     random_state=1,
    #     root='data/',
    #     train=True,
    #     trans=None,
    #     perplexity=None,
    #     v_input=100,
    #     device=None,
    #     func_new=None
    # ):
    #     super(Spheres5500, self).__init__(
    #         n_point=n_point,
    #         random_state=random_state,
    #         root=root,
    #         train=train,
    #         trans=trans,
    #         perplexity=perplexity,
    #         v_input=v_input,
    #         device=device,
    #         func_new=func_new,
    #     )


    def _LoadData(self, n_samples=1500, d=100, bigR=25, n_spheres=11, r=5):
        print('load Spheres5500 dataset')

        np.random.seed(42)
        np.random.seed(self.random_state)

        # it seemed that rescaling the shift variance by sqrt of d lets big sphere stay around the inner spheres
        variance = 10 / np.sqrt(d)
        shift_matrix = np.random.normal(0, variance, [n_spheres, d + 1])

        spheres = []
        n_datapoints = 0
        for i in np.arange(n_spheres - 1):
            sphere = self.dsphere(n=n_samples, d=d, r=r)
            spheres.append(sphere + shift_matrix[i, :])
            n_datapoints += n_samples

        # additional big surrounding sphere
        n_samples_big = 1 * n_samples
        big = self.dsphere(n=n_samples_big, d=d, r=bigR)
        spheres.append(big)
        n_datapoints += n_samples_big

        # create Dataset
        dataset = np.concatenate(spheres, axis=0)

        labels = np.zeros(n_datapoints)
        label_index = 0
        for index, data in enumerate(spheres):
            n_sphere_samples = data.shape[0]
            labels[label_index : label_index + n_sphere_samples] = index
            label_index += n_sphere_samples

        arr = np.arange(dataset.shape[0])
        np.random.shuffle(arr)
        dataset = dataset[arr]/22 + 0.5
        labels = labels[arr]


        self.data = dataset[:self.n_point]
        self.label = labels[:self.n_point]
        self.inputdim = dataset[0].shape

    def dsphere(self, n=100, d=2, r=1, noise=None, ambient=None):
        """
        Sample `n` data points on a d-sphere.
        Arguments:
            n {int} -- number of data points in shape
            r {float} -- radius of sphere
            ambient {int, default=None} -- Embed the sphere into a space with ambient dimension equal to `ambient`. The sphere is randomly rotated in this high dimensional space.
        """
        data = np.random.randn(n, d + 1)

        # normalize points to the sphere
        data = r * data / np.sqrt(np.sum(data ** 2, 1)[:, None])

        if noise:
            data += noise * np.random.randn(*data.shape)

        return data