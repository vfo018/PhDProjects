from loaddata import dataloader_mnist
import torch
import torchvision.datasets as datasets
from sklearn.datasets import make_s_curve
from sklearn.metrics import pairwise_distances
import numpy as np
from loaddata.sigma import PoolRunner
import scipy
from sklearn.preprocessing import StandardScaler
from pynndescent import NNDescent

class FMNIST(dataloader_mnist.MNIST):
    # def __init__(
    #     self,
    #     n_point,
    #     random_state=1,
    #     root='data/',
    #     train=True,
    #     trans=None,
    #     perplexity=None,
    #     v_input=100,
    #     device=None,
    #     func_new=None
    # ):
    #     super(FMNIST, self).__init__(
    #         n_point=n_point,
    #         random_state=random_state,
    #         root=root,
    #         train=train,
    #         trans=trans,
    #         perplexity=perplexity,
    #         v_input=v_input,
    #         device=device,
    #         func_new=func_new,
    #     )


    def _LoadData(self):
        # print('load SCURVE dataset')
        print('load Fmnist dataset')
        dataloader = datasets.FashionMNIST(
            root="./data", train=self.train, download=True, transform=None
        )
        self.data = dataloader.data[:self.n_point].float() / 255
        self.label = dataloader.targets[:self.n_point]
        self.inputdim = self.data[0].shape
        
