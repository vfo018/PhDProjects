from loaddata import dataloader_mnist
import torch
from sklearn.datasets import make_swiss_roll
from sklearn.metrics import pairwise_distances
import numpy as np
from loaddata.sigma import PoolRunner
import scipy
from sklearn.preprocessing import StandardScaler
from pynndescent import NNDescent

class Duplicate(dataloader_mnist.MNIST):
    # def __init__(
    #     self,
    #     n_point,
    #     random_state=1,
    #     root='data/',
    #     train=True,
    #     trans=None,
    #     perplexity=None,
    #     v_input=100,
    #     device=None,
    #     func_new=None
    # ):
    #     super(Duplicate, self).__init__(
    #         n_point=n_point,
    #         random_state=random_state,
    #         root=root,
    #         train=train,
    #         trans=trans,
    #         perplexity=perplexity,
    #         v_input=v_input,
    #         device=device,
    #         func_new=func_new,
    #     )


    def _LoadData(self):
        print('load Duplicate dataset')
        
        np.random.RandomState(self.random_state)

        n = (self.n_point//3)
        data0 = [0.0]*100
        data5 = [5.0]*100
        data10 = [10.0]*100
        
        data = []
        label = []
        for i in range(n):
            data.append(data0)
            data.append(data5)
            data.append(data10)
            label.append(0)
            label.append(1)
            label.append(2)
        data_train = np.array(data)
        label_train = np.array(label)
        
        self.data = data_train
        self.label = label_train
        self.inputdim = self.data[0].shape
