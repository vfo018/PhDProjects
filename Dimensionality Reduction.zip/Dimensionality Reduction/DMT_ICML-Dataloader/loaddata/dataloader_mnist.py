import joblib
import torch
import torchvision.datasets as datasets
from sklearn.metrics import pairwise_distances
import numpy as np
from loaddata.sigma import PoolRunner
import scipy
from sklearn.preprocessing import StandardScaler
from pynndescent import NNDescent

class MNIST(torch.utils.data.Dataset):
    def __init__(
        self,
        n_point,
        random_state=1,
        root='data/',
        train=True,
        trans=None,
        perplexity=None,
        v_input=100,
        device=None,
        K=15,
        func_new=None,
        same_sigma=False,
        metric='metric',
    ):

        self.trains=trans
        self.perplexity = perplexity
        self.v_input = v_input
        self.train = train
        self.n_point = n_point
        self.random_state = random_state
        self.root = root
        self.device = device
        self.K = K
        self.same_sigma=same_sigma

        self.func_new = func_new
        self.metric = metric
    
    def SaveData(self, path):
        joblib.dump(
            value=[
                np.array(self.data.detach().cpu()),
                np.array(self.label.detach().cpu())], 
            filename=path+'data_label.gz',
        )

    def _LoadData(self):

        print('load mnist dataset')
        dataloader = datasets.MNIST(
            root="./data", train=self.train, download=True, transform=None
        )
        self.data = dataloader.data[:self.n_point].float() / 255
        self.label = dataloader.targets[:self.n_point]
        self.inputdim = self.data[0].shape

    def _PretreatmentMaskAndDistance(self, K=15, epsilon=2):

        if K is not None:
            self.K=K
            self.dis_data, self.kNN_data = self.KNNGraph(
                torch.from_numpy(self.data).to(self.device)
                )
        else:
            self.epsilon=epsilon
            self.dis_data, self.kNN_data = self.Epsilonball(
                torch.from_numpy(self.data).to(self.device), epsilon
                )
            
        # self.sigma = sigma
        # self.rho = rho
        self.inputdim = self.data[0].shape

    def _Pretreatment(self, ):

        if self.data.shape[0] > 5000:
            rho, sigma = self._initKNN(
                self.data, perplexity=self.perplexity, v_input=self.v_input)
        else:
            # rho, sigma = self._initPairwiseMahalanobis(
            rho, sigma = self._initPairwise(
                self.data, perplexity=self.perplexity, v_input=self.v_input)
            
        self.sigma = sigma
        self.rho = rho
        self.inputdim = self.data[0].shape

    def _initPairwise(self, X, perplexity, v_input):
        
        print('use pairwise mehtod to find the sigma')

        dist = np.power(
            pairwise_distances(
                X.reshape((X.shape[0],-1)),
                n_jobs=-1,
                metric=self.metric
                ),
                2,
                )
        rho = self._CalRho(dist)

        r = PoolRunner(
            number_point = X.shape[0],
            perplexity=perplexity,
            dist=dist,
            rho=rho,
            gamma=self._CalGamma(v_input),
            v=v_input,
            pow=2,
            func_new=self.func_new)
        sigma = np.array(r.Getout())

        std_dis = np.std(rho) / np.sqrt(X.shape[1])
        print('std_dis', std_dis)
        if std_dis < 0.20 or self.same_sigma is True:
            # sigma[:] = sigma.mean() * 5
            sigma[:] = sigma.mean()
            rho[:] = 0
        # print('sigma', sigma[:10])
        
        return rho, sigma

    def _initPairwiseMahalanobis(self, X, perplexity, v_input):
        
        distold = pairwise_distances(
                X.reshape((X.shape[0],-1)),
                n_jobs=-1)
                
        # distold = np.power(distold,1/2)

        # print(dist)
        dist = np.zeros((X.shape[0], X.shape[0]))
        for i in range(dist.shape[0]):
            dist_item = pairwise_distances(
                X.reshape((X.shape[0],-1))[i:i+1,:],
                X.reshape((X.shape[0],-1))
            )
            sort_index = np.argsort(dist_item)[0][0:5]
            m = MahalanobisDistance(X[sort_index])
            for j in range(dist.shape[0]):
                dist[i,j] = m(X[i],X[j])
            alpha = dist[i][sort_index].mean()/distold[i][sort_index].mean()
            dist[i] = dist[i]/alpha

        dist = np.power(dist,2)
        # print(dist)
        # input()

        rho = self._CalRho(dist)

        r = PoolRunner(
            number_point = X.shape[0],
            perplexity=perplexity,
            dist=dist,
            rho=rho,
            gamma=self._CalGamma(v_input),
            v=v_input,
            pow=2,
            func_new=self.func_new)
        sigma = np.array(r.Getout())

        std_dis = np.std(rho) / np.sqrt(X.shape[1])
        print('std_dis', std_dis)
        if std_dis < 0.20 or self.same_sigma is True:
            sigma[:] = sigma.mean() * 5
            rho[:] = 0
        
        return rho, sigma

    def _initKNN(self, X, perplexity, v_input, K=500):
        
        print('use kNN mehtod to find the sigma')

        X_rshaped = X.reshape((X.shape[0],-1))
        index = NNDescent(X_rshaped, n_jobs=-1, metric=self.metric)
        neighbors_index, neighbors_dist = index.query(X_rshaped, k=K )
        neighbors_dist = np.power(neighbors_dist, 2)
        rho = neighbors_dist[:, 1]

        r = PoolRunner(
            number_point = X.shape[0],
            perplexity=perplexity,
            dist=neighbors_dist,
            rho=rho,
            gamma=self._CalGamma(v_input),
            v=v_input,
            pow=2)
        sigma = np.array(r.Getout())

        std_dis = np.std(rho) / np.sqrt(X.shape[1])
        print('std_dis', std_dis)
        if std_dis < 0.20 or self.same_sigma is True:
            # sigma[:] = sigma.mean() * 5
            sigma[:] = sigma.mean()
        # print('sigma', sigma)
        return rho, sigma

    # def _initKnnHNSW(self, X, perplexity, v_input, K=500):
        
    #     import faiss

    #     print('use kNN mehtod to find the sigma')

    #     X_rshaped = np.array(X.reshape((X.shape[0],-1)))
    #     # index = NNDescent(X_rshaped, n_jobs=-1, metric=self.metric)
    #     index = faiss.IndexFlatL2(X_rshaped.shape[1])
    #     # index.add(X_rshaped)
    #     neighbors_dist, I = index.search(X_rshaped, K)

    #     # labels,  = p.knn_query(X_rshaped, k=K)

    #     # neighbors_index, neighbors_dist = index.query(X_rshaped, k=K )
    #     neighbors_dist = np.power(neighbors_dist, 2)
    #     rho = neighbors_dist[:, 1]

    #     r = PoolRunner(
    #         number_point = X.shape[0],
    #         perplexity=perplexity,
    #         dist=neighbors_dist,
    #         rho=rho,
    #         gamma=self._CalGamma(v_input),
    #         v=v_input,
    #         pow=2)
    #     sigma = np.array(r.Getout())

    #     std_dis = np.std(rho) / np.sqrt(X.shape[1])
    #     print('std_dis', std_dis)
    #     if std_dis < 0.20 or self.same_sigma is True:
    #         # sigma[:] = sigma.mean() * 5
    #         sigma[:] = sigma.mean()
    #     print(sigma)
    #     return rho, sigma


    def _CalRho(self, dist):
        dist_copy = np.copy(dist)
        row, col = np.diag_indices_from(dist_copy)
        dist_copy[row,col] = 1e16
        rho = np.min(dist_copy, axis=1)
        return rho
    
    def _CalGamma(self, v):
        a = scipy.special.gamma((v + 1) / 2)
        b = np.sqrt(v * np.pi) * scipy.special.gamma(v / 2)
        out = a / b
        return out
    
    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (image, target) where target is index of the target class.
        """

        # if index in self.data:
        # data_item = self.data[index]
        # rho_item = self.rho[index]
        # sigma_item = self.sigma[index]
        label_item = self.label[index]

        # if self.trains is not None:
        #     data_item = self.trains(data_item)

        return index, label_item


    def KNNGraph(self, data, k=15):

        """
        another function used to calculate the distance between point pairs and determine the neighborhood
        Arguments:
            data {tensor} -- the train data
        Outputs:
            d {tensor} -- the distance between point pairs
            kNN_mask {tensor} a mask used to determine the neighborhood of every data point
        """

        if self.K < 1:
            k = int(self.K*data.shape[0])
        else:
            k = self.K
        batch_size = data.shape[0]

        x = data.to(self.device)
        y = data.to(self.device)
        m, n = x.size(0), y.size(0)
        xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
        yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
        dist = xx + yy
        # dist.addmm_(1, -2, x, y.t())
        dist = torch.addmm(dist, mat1=x, mat2=y.t(),beta=1, alpha=-2)
        d = dist.clamp(min=1e-8).sqrt()  # for numerical stabili

        s_, indices = torch.sort(d, dim=1)
        indices = indices[:, :k+1]
        kNN_mask = torch.zeros(
            (batch_size, batch_size,),
            device=self.device
            ).scatter(1, indices, 1)
        kNN_mask[torch.eye(kNN_mask.shape[0], dtype=int)] = 0

        return d, kNN_mask.bool()


    def Epsilonball(self, data, epsilon=2):

        """
        function used to calculate the distance between point pairs and determine the neighborhood with r-ball
        Arguments:
            data {tensor} -- the train data
        Outputs:
            d {tensor} -- the distance between point pairs
            kNN_mask {tensor} a mask used to determine the neighborhood of every data point
        """

        # epsilon = self.epsilon

        x = data.to(self.device)
        y = data.to(self.device)
        m, n = x.size(0), y.size(0)
        xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
        yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
        dist = xx + yy
        # dist.addmm_(1, -2, x, y.t())
        dist = torch.addmm(dist, mat1=x, mat2=y.t(),beta=1, alpha=-2)
        d = dist.clamp(min=1e-8).sqrt()

        kNN_mask = (d < epsilon).bool()

        return d, kNN_mask

class MahalanobisDistance():
    def __init__(self, X):
        self._PCA = None
        self._mean_x = np.mean(X, axis=0)
        X = X.reshape(X.shape[0], -1)
        mean_removed = X # - self._mean_x
        cov = np.cov(mean_removed, rowvar=False)
        if np.linalg.det(cov) == 0.0:
            eig_val, eig_vec = np.linalg.eig(cov)
            e_val_index = np.argsort(-eig_val)
            e_val_index = e_val_index[e_val_index > 1e-3]  
            self._PCA = eig_vec[:, e_val_index] 
            PCA_X = np.dot(X, self._PCA)  
            self._mean_x = PCA_X.mean(axis=0) 
            mean_removed = PCA_X # - self._mean_x
            cov = np.cov(mean_removed, rowvar=False)
            
        self._cov_i = np.linalg.inv(cov) 
        
    def __call__(self, X, y=None):
        if y is None:
            y = self._mean_x
        X_data = X.copy()
        if self._PCA is not None:
            X_data = np.dot(X_data, self._PCA)
        X_data = X_data - y
        distance = np.dot(np.dot(X_data, self._cov_i), X_data.T)
        if len(X.shape) != 1:
            distance = distance.diagonal()
            
        return np.sqrt(distance)