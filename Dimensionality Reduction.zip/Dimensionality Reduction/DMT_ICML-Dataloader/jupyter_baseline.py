#%%
import random
import joblib
import param.param_DMTsame_sigma as paramzzl
import torch
import tool
import loaddata.dataloader_main_dmt as dataloader_main
import umap
from sklearn.manifold import TSNE
from sklearn.manifold import LocallyLinearEmbedding
import numpy as np
from sklearn.metrics import pairwise_distances
import param.param_DMTsame_sigma as param_use
import Similarity.sim_tdis as Sim_use
try:
    import eval.eval_core as eval_core
except:
    import eval_core

#%% run the umap code

def Testbaseline(args, baseline='umap', k=15):

    tool.SetSeed(args['seed'])
    path = tool.GetPath('baseline_{}_'.format(baseline)+args['data_name']+'_'+args['name'])
    device = torch.device('cpu')
    dataloader, dataset = dataloader_main.Getdataloader(
        data_name=args['data_name'],
        n_point=args['data_trai_n'],
        batch_size=args['batch_size'],
        perplexity=args['perplexity'],
        device=device,
        func_new=Sim_use.func_tdis,
        v_input=args['vinput'],
        same_sigma=args['same_sigma'],
        metric=args['metric'],
        )
    dataset.SaveData(path)
    data = dataset.data.reshape((dataset.data.shape[0],-1))
    print(data.shape)
    label = dataset.label

    if baseline=='umap':
        emb = umap.UMAP(n_neighbors=k).fit_transform(data)
    if baseline=='tsne':
        emb = TSNE(perplexity=k).fit_transform(data)
        
    if baseline=='mlle':
        if args['data_name']=='swishroll' or args['data_name']=='scurve':
            emb = LocallyLinearEmbedding(n_components=2, n_neighbors=k, method='modified').fit_transform(data)
        else:
            emb = LocallyLinearEmbedding(n_components=2).fit_transform(data)

    gifPloterLatentTrain = tool.GIFPloter()
    gifPloterLatentTrain.AddNewFig(
        emb,
        np.array(label),
        his_loss=None,
        path=path,
        graph=None,
        link=None,
        title_='baselin_{}_em_{}k_{}.png'.format(baseline, args['data_name'], k)
        )
    return emb, label, path

# args = paramzzl.GetParamToyDiffStd()
def main(args):

    # for k in [5, 10, 20, 40, 80, 160, 320, 640]:
    path = []
    for k in [10]:
        emb, label, p = Testbaseline(args, baseline='umap', k=k)
        path.append(p)
        emb, label, p = Testbaseline(args, baseline='tsne', k=k)
        path.append(p)
        emb, label, p = Testbaseline(args, baseline='mlle', k=k)
        path.append(p)

    return path
if __name__ == "__main__":
    # args = param_use.GetParamToyDuplicate()
    # args = param_use.GetParamswishroll()
    # args = param_use.GetParamScurve()
    # args = param_use.GetParamDigits()
    # args = param_use.GetParamseveredsphere()
    # args = param_use.GetParamSphere5500()
    # args = param_use.GetParamSphere10000()
    # args = param_use.GetParamcoil20()
    # args = param_use.GetParamCoil100()
    # args = param_use.GetParamSMILE()
    # args = param_use.GetParamSMILEpluse()
    # args = param_use.GetParamSumsink()
    # args = param_use.GetParamPBMC()
    # args = param_use.GetParamMnistLSUB()
    # args = param_use.GetParamMnistL()
    args = param_use.GetParamFMnistL()
    # args = param_use.GetParamToyDuplicate()
    # args = param_use.GetParamToyDiffStd()
    # args = param_use.GetParamCifar10()
    # args = param_use.GetParamCifar10Sub()
    # args = param_use.GetParamPbmc3k()
    main(args)
# #%% load the result of dmt
# path = 'log/20210129035525_6461asumsink_autotrain,batch_size_300_/train_epoch_em800_10.png.gz'
# emb, label = joblib.load(path)
# # %% test the dmt result
# list_dis = []
# for i in list(set(label)):
#     p = emb[label==i]
#     m = p.mean(axis=0)[None,:]
#     print(p.shape)
#     list_dis.append(np.power(pairwise_distances(p,m),2).mean())
#     # print(list_dis)
# list_dis = np.array(list_dis)
# print(emb.shape)
# list_dis_norm=list_dis/list_dis.max()
# print(list_dis_norm)
# print(np.argsort(list_dis_norm))
# # %% desk 


# args = param_use.GetParamMnistLSUB()
# device = torch.device('cpu')
# dataloader, dataset = dataloader_main.Getdataloader(
#     data_name=args['data_name'],
#     n_point=args['data_trai_n'],
#     batch_size=args['batch_size'],
#     perplexity=args['perplexity'],
#     device=device,
#     func_new=Sim_use.func_tdis,
#     v_input=args['vinput'],
#     same_sigma=args['same_sigma'],
#     metric=args['metric'],
#     )
# list_dis = []
# dataset.data = dataset.data.cpu().numpy().reshape(dataset.data.shape[0],-1)
# dataset.label = dataset.label.cpu().numpy()
# for i in range(10):
#     p = dataset.data[dataset.label==i]
#     m = p.mean(axis=0)[None,:]
#     list_dis.append(np.power(pairwise_distances(p,m),2).mean())
#     # print(m.shape)
#     # list_dis.append(pairwise_distances(p, p).mean())
# list_dis = np.array(list_dis)
# print(dataset.data.shape)
# list_dis_norm=list_dis/list_dis.max()
# print(list_dis_norm)
# print(np.argsort(list_dis_norm))
# %%


# path = 'log/20210129035527_6461asumsink_autotrain,batch_size_150_/train_epoch_em600_10.png.gz'
# emb, label = joblib.load(path)

# import tool
# gp = tool.GIFPloter()
# gp.AddNewFig(emb, label,title_='ppp.png')

# %%

# args = paramzzl.GetParamCifar10()
# device = torch.device('cpu')
# dataloader, dataset = dataloader_main.Getdataloader(
#     data_name=args['data_name'],
#     n_point=args['data_trai_n'],
#     batch_size=args['batch_size'],
#     perplexity=args['perplexity'],
#     device=device,
#     func_new=Sim_use.func_tdis,
#     v_input=args['vinput'],
#     same_sigma=args['same_sigma'],
#     metric=args['metric'],
#     )
# data = dataset.data.reshape((dataset.data.shape[0],-1))
# print(data.shape)
# label = dataset.label
# from sklearn.metrics import accuracy_score
# from sklearn.neighbors import KNeighborsClassifier
# neigh = KNeighborsClassifier(n_neighbors=3, metric='euclidean', n_jobs=-1)
# neigh.fit(data, label)
# print(accuracy_score(label, neigh.predict(data)))