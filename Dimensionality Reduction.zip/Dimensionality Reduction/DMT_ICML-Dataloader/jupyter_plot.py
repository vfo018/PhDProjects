
import numpy as np
import joblib
import matplotlib.pyplot as plt
import eval.main_test as main_test
from sklearn.metrics import pairwise_distances
import seaborn

# path_umap_full = 'log/20210202140840_3ee4bbaseline_umap_mnist_emnistL_T/baselin_umap_em_mnistk_10.png.gz'
# path_dmt_full = 'log/20210202135134_3ee4bmnist_emnistL_T/train_epoch_em01000_60.png.gz'
# path_origin_ful = 'log/20210202135134_3ee4bmnist_emnistL_T/data_label.gz'
# path_umap_sub = 'log/20210202151636_63114baseline_umap_mnistsub0_mnistsub0_T/baselin_umap_em_mnistsub0k_10.png.gz'
# path_dmt_sub = 'log/20210202153529_63114mnistsub0_mnistsub0_T/train_epoch_em01000_60.png.gz'
# path_origin_sub = 'log/20210202153529_63114mnistsub0_mnistsub0_T/data_label.gz'

# r_all = None
# r_all = main_test.TestwithLink_meta(path_origin_ful, path_umap_full)
# r_all = main_test.TestwithLink_meta(path_origin_ful, path_dmt_full)
# r_all = main_test.TestwithLink_meta(path_origin_sub, path_umap_sub)
# r_all = main_test.TestwithLink_meta(path_origin_sub, path_dmt_sub)


pl = [
'log/20210203184923_ab862coil20_autotrain,perplexity_5_',
'log/20210203184923_ab862coil20_autotrain,perplexity_10_',
'log/20210203184924_ab862coil20_autotrain,perplexity_20_',
'log/20210203184929_ab862coil20_autotrain,perplexity_30_',
'log/20210203184929_ab862coil20_autotrain,perplexity_40_',
'log/20210203184929_ab862coil20_autotrain,perplexity_60_',
'log/20210203184929_ab862coil20_autotrain,perplexity_80_',
]



# for path in pl:
path = 'log/20210205115348_c9c55coil20_coil20_T/train_epoch_em03000_10.png.gz'
emb, label = joblib.load(path)

fig = plt.figure(figsize=(5, 5))
ax = fig.add_subplot(1, 1, 1)

s = ax.scatter(emb[:, 0],
                emb[:, 1],
                c=label,
                s=1,
                )
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['bottom'].set_visible(False)
ax.spines['left'].set_visible(False)
plt.xticks([])
plt.yticks([])
plt.tight_layout()

plt.savefig('80zzl.png', dpi=500)



# path='log/20210204103308_ab862toy_diff_std_toy_diff_std_T/data_label.gz'
# emb, label=joblib.load(path)
# dis = pairwise_distances(emb, emb)
# dis_0 = dis.sum(axis=0)
# index_0 = np.argsort(dis_0)
# dis_1 = dis.sum(axis=1)
# index_1 = np.argsort(dis_1)
# print(index_0)
# dis = dis[index_0,:][:,index_1]

# seaborn.heatmap(dis)
# plt.savefig('zzlinput.png')
# plt.close()


# path='log/20210204103104_ab862toy_diff_std_toy_diff_std_T/train_epoch_em05000_5.png.gz'

# emb, label=joblib.load(path)
# dis = pairwise_distances(emb, emb)
# # dis_0 = dis.sum(axis=0)
# # index_0 = np.argsort(dis_0)
# # dis_1 = dis.sum(axis=1)
# # index_1 = np.argsort(dis_1)
# print(index_0)
# dis = dis[index_0,:][:,index_1]/25

# seaborn.heatmap(dis)
# plt.savefig('zzldmtemb.png')


# path='log/20210204103104_ab862toy_diff_std_toy_diff_std_T/train_epoch_em05000_5.png.gz'

# emb, label=joblib.load(path)
# dis = pairwise_distances(emb, emb)
# # dis_0 = dis.sum(axis=0)
# # index_0 = np.argsort(dis_0)
# # dis_1 = dis.sum(axis=1)
# # index_1 = np.argsort(dis_1)
# print(index_0)
# dis = dis[index_0,:][:,index_1]/25

# seaborn.heatmap(dis)
# plt.savefig('zzldmtemb.png')