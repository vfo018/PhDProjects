
# import sys 
# sys.path.append("..") 

import main_dmt
import jupyter_baseline
import param.param_DMTsame_sigma as param_use
import eval.main_test as main_test

 
if __name__ == "__main__":

    args_list = [
        # param_use.GetParamswishroll(),
        # param_use.GetParamScurve(),
        # param_use.GetParamSMILEpluse(),
        # param_use.GetParamToyDiffStd(),
        # param_use.GetParamToyDuplicate(),
        
        # param_use.GetParamSphere5500(),·
        # param_use.GetParamSphere10000(),
        # param_use.GetParamcoil20(),
        # param_use.GetParamCoil100(),
        # param_use.GetParamcoil20Fortime()
        # # param_use.GetParamCoil100ForTime(),
        # # param_use.GetParamDigits(),
        # param_use.GetParamMnistL(),
        # # param_use.GetParamMnistLSUB(),
        param_use.GetParamFMnistL(),
        # # param_use.GetParamCifar10(),
        # param_use.GetParamCifar10Sub(),
        # # param_use.GetParamImagenet10(),
    ]

    # args = param_use.GetParamswishroll()
    # # args = param_use.GetParamyj01()
    # # args = param_use.GetParamScurve()
    # # args = param_use.GetParamDigits()
    # # args = param_use.GetParamseveredsphere()
    # # args = param_use.GetParamSphere5500()
    # # args = param_use.GetParamSphere10000()
    # # args = param_use.GetParamcoil20()
    # # args = param_use.GetParamCoil100()
    # # args = param_use.GetParamSMILE()
    # # args = param_use.GetParamSMILEpluse()
    # # args = param_use.GetParamSumsink()
    # # args = param_use.GetParamPBMC()
    # # args = param_use.GetParamMnistLSUB()
    # # args = param_use.GetParamMnistL()
    # # args = param_use.GetParamFMnistL()
    # # args = param_use.GetParamToyDuplicate()
    # # args = param_use.GetParamToyDiffStd()
    # # args = param_use.GetParamCifar10()
    # # args = param_use.GetParamCifar10Sub()
    # # args = param_use.GetParamPbmc3k()
    for args in args_list:
        args['Dec']=True
        path_s = []
        path_s.append(main_dmt.main(args))
        # path_s += jupyter_baseline.main(args)
        # print(path)

        # r_all = None
        # for p in path_s:
        #     r_all = main_test.TestwithLink(p+'/', r_all)
        #     print(r_all)
        #     r_all.to_csv('eval/results/{}dataset{}test.csv'.format(args['name'],args['data_name']))