from typing import Any
import numpy as np
import torch
from torch import nn, set_flush_denormal
from torch._C import device
import torch.optim as optim
from multiprocessing import Pool

import Loss.dmt_loss_twowaydivergenceLoss as Loss_use
# import Loss.dmt_loss_L2 as Loss_use
# import Loss.dmt_loss_L3 as Loss_use
# import Loss.dmt_loss_ItakuraSaito as Loss_use
# import Loss.dmt_loss_GID as Loss_use

import model.dmt_model as model_use
# import model.dmt_model_unparam as model_use

import Similarity.sim_tdis as Sim_use
# import Similarity.sim_tdisp1 as Sim_use
# import Similarity.sim_Cauchy as Sim_use
# import Similarity.sim_tdisGaussian as Sim_use

# import param.param_DMT as param_use
import param.param_DMTsame_sigma as param_use
# import param.param_DMTp1 as param_use
# import param.param_DMTCauchy as param_use
# import param.param_DMTGaussian as param_use


from tqdm import trange
import loaddata.dataloader_main_dmt as dataloader_main
import nuscheduler


import tool
# import resource
# soft, hard = resource.getrlimit(resource.RLIMIT_AS)
# resource.setrlimit(resource.RLIMIT_AS, (int(0.5 * 1024 ** 6), hard))

torch.set_num_threads(1)

def train(
        Model: Any,
        Loss: Any,
        dataset: Any,
        nushadular:Any,
        dataloader: Any,
        optimizer: Any,
        current_epoch: int,
        DEC=False,
        ):

    # print(current_epoch)
    Model.train()

    loss_list = []
    dataloader.reset()
    while dataloader.epochend():
        batch_idx, index_data=dataloader.load()

        input_data = dataset.data[index_data]
        rho = dataset.rho[index_data]
        sigma = dataset.sigma[index_data]

        if Model.model_type=='mlp' and len(input_data.shape) >= 2:
            input_data_model = input_data.reshape((input_data.shape[0], -1))
            input_data_loss = input_data_model
        if Model.model_type=='cnn' and len(input_data.shape) < 4:
            s = input_data.shape
            input_data_model = input_data.reshape((s[0], 1, s[1], s[2])).expand((s[0], 3, s[1], s[2]))
            input_data_loss = input_data.reshape((input_data.shape[0], -1))
        if Model.model_type=='cnn' and len(input_data.shape) == 4:
            # input_data_model = input_data
            input_data_model = input_data.transpose(1,3).transpose(2,3)
            input_data_loss = input_data.reshape((input_data.shape[0], -1))

        index_data = index_data.long().to(Model.device)
        input_data_model = input_data_model.float().to(Model.device)
        input_data_loss = input_data_loss.float().to(Model.device)
        rho = rho.reshape(-1,1).float().to(Model.device)
        sigma = sigma.reshape(-1,1).float().to(Model.device)

        latent_data = Model(input_data_model, index=index_data)
        
        if DEC:
            r = Model.decf(latent_data)

        loss = Loss(
            input_data=input_data_loss,
            latent_data=latent_data,
            rho=rho,
            sigma=sigma,
            v_latent=nushadular.Getnu(current_epoch)
            )

        if DEC:
            cr = nn.MSELoss()
            l = cr( Model.decf(latent_data), input_data_model)
            loss+=l


        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        loss_list.append(loss.detach().cpu().numpy())
    return np.sum(loss_list)


def Test(
        Model: Any,
        Loss: Any,
        dataset: Any,
        dataloader: Any,
        optimizer: Any,
        current_epoch: int,
        ):

    Model.eval()
    dataloader.reset()
    
    outem = np.zeros(shape=(dataset.data.shape[0] ,2))
    outla = np.zeros(shape=(dataset.data.shape[0]))
    
    while dataloader.epochend():
        batch_idx, index_data=dataloader.load()
        input_data = dataset.data[index_data]
        label_data = dataset.label[index_data]

        if Model.model_type=='mlp' and len(input_data.shape) >= 2:
            input_data_model = input_data.reshape((input_data.shape[0], -1))
            input_data_loss = input_data_model
        if Model.model_type=='cnn' and len(input_data.shape) < 4:
            s = input_data.shape
            input_data_model = input_data.reshape((s[0], 1, s[1], s[2])).expand((s[0], 3, s[1], s[2]))
            input_data_loss = input_data.reshape((input_data.shape[0], -1))
        if Model.model_type=='cnn' and len(input_data.shape) == 4:
            input_data_model = input_data.transpose(1,3)
            input_data_loss = input_data.reshape((input_data.shape[0], -1))

        index_data = index_data.long().to(Model.device)
        input_data_model = input_data_model.float().to(Model.device)
        input_data_loss = input_data_loss.float().to(Model.device)

        latent_data = Model(input_data_model, index=index_data)

        index_data = index_data.detach().cpu().numpy()
        outem[index_data,:] = latent_data.detach().cpu().numpy()
        outla[index_data] = label_data.detach().cpu().numpy()


    return outem, outla


def main(args: dict, data_train=None, label_train=None, data_test=None, label_test=None):

    tool.SetSeed(args['seed'])
    path = tool.GetPath(args['data_name']+'_'+args['name'])
    tool.SaveParam(path, args)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    dataloader, dataset = dataloader_main.Getdataloader(
        data_name = args['data_name'],
        n_point = args['data_trai_n'],
        batch_size = args['batch_size'],
        perplexity = args['perplexity'],
        device = device,
        func_new = Sim_use.func_tdis,
        v_input = args['vinput'],
        same_sigma = args['same_sigma'],
        metric = args['metric'],
        train = True
        )
    dataloader_test, dataset_test = dataloader_main.Getdataloader(
        data_name = args['data_name'],
        n_point = args['data_trai_n'],
        batch_size = args['batch_size'],
        perplexity = args['perplexity'],
        device = device,
        func_new = Sim_use.func_tdis,
        v_input = args['vinput'],
        same_sigma = args['same_sigma'],
        metric = args['metric'],
        random_state=2,
        train=False
        )
    dataset.SaveData(path=path+'/')
    dataset_test.SaveData(path=path+'/test')
    tool.SetSeed(args['seed'])

    nushadular = nuscheduler.Nushadular(
        nu_start=args['vtrace'][0],
        nu_end=args['vtrace'][1],
        epoch_start=args['epochs']//5,
        epoch_end=args['epochs']*4//5,
    )
    
    # # Loss = dmt_loss_fast.LISV2_Loss(data_train, device=device, args=args, path=path).to(device)
    Loss = Loss_use.MyLoss(
        v_input=args['vinput'], device=device,
        SimilarityFunc=Sim_use.Similarity
        ).to(device)
    Model = model_use.LISV2_Model(
        input_dim=dataset.inputdim,
        device=device,
        NetworkStructure=args['NetworkStructure'],
        dataset_name=args['data_name'],
        model_type=args['model_type'],
        num_point=args['data_trai_n'],
        input_data=dataset.data,
        DEC=args['Dec'],
        ).to(device)

    optimizer = optim.Adam(Model.parameters(), lr=args['lr'])
    # optimizer = optim.SGD(Model.parameters(), lr=args['lr'])

    gifPloterLatentTrain = tool.GIFPloter()
    # gifPloterLatentTest = tool.GIFPloter()
    # gifPloterrecons = tool.GIFPloter()
    
    with trange(0, args['epochs'] + 1) as trange_handle:
        for epoch in trange_handle:
            # Loss.epoch = epoch
            if epoch > 0:
                loss_item = train(
                    Model=Model,
                    Loss=Loss,
                    dataset=dataset,
                    nushadular=nushadular,
                    dataloader=dataloader,
                    optimizer=optimizer,
                    current_epoch=epoch,
                    DEC=args['Dec']
                    )
            else:
                loss_item=1

            if epoch == 100:
                for param_group in optimizer.param_groups:
                    param_group["lr"] = param_group["lr"] / 5
                print('change the learning rate')

            if epoch == 300:
                for param_group in optimizer.param_groups:
                    param_group["lr"] = param_group["lr"] / 5
                print('change the learning rate')

            if epoch == 5000:
                for param_group in optimizer.param_groups:
                    param_group["lr"] = param_group["lr"] / 10
                print('change the learning rate')

            if epoch % args['log_interval'] == 0:

                em_train, re_train = Test(
                    Model=Model,
                    Loss=Loss,
                    dataset=dataset,
                    dataloader=dataloader,
                    optimizer=optimizer,
                    current_epoch=epoch,
                    )
                print(em_train.shape)
                gifPloterLatentTrain.AddNewFig(
                    em_train,
                    re_train,
                    his_loss=None,
                    path=path,
                    graph=None,
                    link=None,
                    title_='train_epoch_em{}_{}.png'.format(
                        str(epoch).zfill(5), args['perplexity'])
                    )

            trange_handle.set_postfix(loss=loss_item, nu=nushadular.Getnu(epoch))
            
    gifPloterLatentTrain.SaveGIF()
    return path


if __name__ == "__main__":

    # args = param_use.GetParamswishroll()
    # path = main(args)
    # args = param_use.GetParamScurve()
    # path = main(args)
    # args = param_use.GetParamDigits()
    # path = main(args)
    # args = param_use.GetParamToyDuplicate()
    # path = main(args)
    # args = param_use.GetParamToyDiffStd()
    # path = main(args)
    # args = param_use.GetParamseveredsphere()
    # path = main(args)
    # args = param_use.GetParamSphere5500()
    # path = main(args)
    # args = param_use.GetParamSphere10000()
    # path = main(args)
    # args = param_use.GetParamcoil20()
    # path = main(args)
    # args = param_use.GetParamCoil100()
    # path = main(args)
    # args = param_use.GetParamSMILE()
    # path = main(args)
    # args = param_use.GetParamSMILEpluse()
    # path = main(args)
    # args = param_use.GetParamSumsink()
    # path = main(args)
    # args = param_use.GetParamPBMC()
    # path = main(args)
    # args = param_use.GetParamMnistLSUB()
    # path = main(args)
    # args = param_use.GetParamImagenet10()
    # path = main(args)
    # args = param_use.GetParamGoogleWord()
    # path = main(args)
    args = param_use.GetParamMnistL()
    args['epochs']=100
    path = main(args)
    # args = param_use.GetParamFMnistL()
    # path = main(args)
    # args = param_use.GetParamCifar10()
    # path = main(args)
    # args = param_use.GetParamCifar10Sub()
    # path = main(args)
    # args = param_use.GetParamPbmc3k()
    # path = main(args)

    # import indicator
    # indicator.main()
